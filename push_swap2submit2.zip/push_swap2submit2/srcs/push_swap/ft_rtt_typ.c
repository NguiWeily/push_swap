/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rtt_typ.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:28:04 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:28:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../incl/push_swap.h"

int	ft_rtt_typ_ba(t_stack *a, t_stack *b)
{
	int		i;
	t_stack	*tmp;

	tmp = b;
	i = ft_cas_rrarrb_a(a, b, b->nbr);
	while (tmp)
	{
		if (i > ft_cas_rarb_a(a, b, tmp->nbr))
			i = ft_cas_rarb_a(a, b, tmp->nbr);
		if (i > ft_cas_rrarrb_a(a, b, tmp->nbr))
			i = ft_cas_rrarrb_a(a, b, tmp->nbr);
		if (i > ft_cas_rarrb_a(a, b, tmp->nbr))
			i = ft_cas_rarrb_a(a, b, tmp->nbr);
		if (i > ft_cas_rrarb_a(a, b, tmp->nbr))
			i = ft_cas_rrarb_a(a, b, tmp->nbr);
		tmp = tmp->next;
	}
	return (i);
}

int	ft_rtt_typ_ab(t_stack *a, t_stack *b)
{
	int		i;
	t_stack	*tmp;

	tmp = a;
	i = ft_cas_rrarrb(a, b, a->nbr);
	while (tmp)
	{
		if (i > ft_cas_rarb(a, b, tmp->nbr))
			i = ft_cas_rarb(a, b, tmp->nbr);
		if (i > ft_cas_rrarrb(a, b, tmp->nbr))
			i = ft_cas_rrarrb(a, b, tmp->nbr);
		if (i > ft_cas_rarrb(a, b, tmp->nbr))
			i = ft_cas_rarrb(a, b, tmp->nbr);
		if (i > ft_cas_rrarb(a, b, tmp->nbr))
			i = ft_cas_rrarb(a, b, tmp->nbr);
		tmp = tmp->next;
	}
	return (i);
}
