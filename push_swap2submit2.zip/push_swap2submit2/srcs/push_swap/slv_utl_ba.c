/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   slv_utl_ba.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:38:39 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:38:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../incl/push_swap.h"

int	ft_cas_rarb_a(t_stack *a, t_stack *b, int c)
{
	int	i;

	i = ft_fnd_place_a(a, c);
	if (i < ft_fnd_index(b, c))
		i = ft_fnd_index(b, c);
	return (i);
}

int	ft_cas_rrarrb_a(t_stack *a, t_stack *b, int c)
{
	int	i;

	i = 0;
	if (ft_fnd_place_a(a, c))
		i = ft_lstsize(a) - ft_fnd_place_a(a, c);
	if ((i < (ft_lstsize(b) - ft_fnd_index(b, c))) && ft_fnd_index(b, c))
		i = ft_lstsize(b) - ft_fnd_index(b, c);
	return (i);
}

int	ft_cas_rarrb_a(t_stack *a, t_stack *b, int c)
{
	int	i;

	i = 0;
	if (ft_fnd_index(b, c))
		i = ft_lstsize(b) - ft_fnd_index(b, c);
	i = ft_fnd_place_a(a, c) + i;
	return (i);
}

int	ft_cas_rrarb_a(t_stack *a, t_stack *b, int c)
{
	int	i;

	i = 0;
	if (ft_fnd_place_a(a, c))
		i = ft_lstsize(a) - ft_fnd_place_a(a, c);
	i = ft_fnd_index(b, c) + i;
	return (i);
}
