/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:33:41 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:33:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

int	main(int argc, char **argv)
{
	t_stack	*a;

	a = ft_process(argc, argv);
	if (!a || ft_chk_dup(a))
	{
		ft_fre(&a);
		ft_err();
	}
	if (!ft_chk_srt(a))
		ft_sort(&a);
	ft_fre(&a);
	return (0);
}
