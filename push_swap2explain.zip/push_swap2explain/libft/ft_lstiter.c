/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstiter.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:25:32 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:25:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_lstiter iterates over a linked list and applies a function f to each element's content. It takes a pointer to the first element of the list (lst) and a pointer to a function (f) that takes a pointer to void and returns void. It first checks if lst is not NULL. If lst is not NULL, it initializes a pointer next to point to the first element in the list and then enters an infinite loop. In each iteration, it calls the function f on the content of the current element (next->content), moves next to point to the next element in the list, and checks if next is NULL (indicating the end of the list). If next is NULL, it breaks out of the loop and returns from the function.*/

void ft_lstiter(t_list *lst, void (*f)(void *))
{
	t_list *next;  // Pointer to the next element in the list

	if (lst != NULL)  // Check if lst is not NULL
	{
		next = lst;  // Initialize next to point to the first element in the list
		while (1)  // Infinite loop (will break when we reach the end of the list)
		{
			(*f)(next->content);  // Call the function f on the content of the current element
			next = next->next;  // Move next to the next element in the list
			if (next == NULL)  // If next is NULL, we have reached the end of the list
				return ;  // Return from the function
		}
	}
}

