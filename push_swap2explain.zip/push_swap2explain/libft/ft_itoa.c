/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:55:47 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:55:50 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
/*
 ** count_cipher(int n): count cipher number, including sign minus.
 ** If the number is negative, we put the - sign to the left. 
 ** Once we enter the function str_numb,
 ** we will start placing numbers from the right to left. 
 ** So We will never overwrite the - sign if there is one,
 ** as the while condition (n > 0) of strn_number will prevent it.
 ** To handle the limiting case long long -2147483648LL,
 ** we have to convert the int n to unsigned int (we can cast it)
 This code defines a function ft_itoa that converts an integer to a string. It first calculates the number of digits in the integer, allocates memory for the string, and then converts each digit of the integer to a character, storing them in the string. If the integer is negative, it adds a negative sign to the string. Finally, it returns the resulting string.
*/
static size_t count_cipher(int n)
{
	size_t cipher;  // Variable to store the number of digits in the number

	cipher = 0;  // Initialize cipher to 0
	if (n <= 0)  // If the number is negative or zero
		cipher++;  // Increment cipher to account for the negative sign
	while (n)  // Loop until n becomes 0
	{
		n = n / 10;  // Divide n by 10 to remove the rightmost digit
		cipher++;  // Increment cipher for each digit
	}
	return (cipher);  // Return the number of digits
}

char *str_numb(char *number, unsigned int n, int cipher)
{
	while (n > 0)
	{
		number[cipher--] = n % 10 + '0';  // Convert the rightmost digit of n to char and store it in the array
		n = n / 10;  // Remove the rightmost digit of n
	}
	return (number);
}

char *ft_itoa(int n)
{
	char *number_str;  // Pointer to the resulting string
	int cipher;  // Number of digits in the number

	cipher = count_cipher(n);  // Count the number of digits in n
	number_str = (char *)malloc(sizeof(char) * cipher + 1);  // Allocate memory for the string
	if (!number_str)  // If memory allocation fails
		return (NULL);  // Return NULL
	number_str[cipher--] = '\0';  // Null-terminate the string
	if (n == 0)  // If n is 0
	{
		number_str[cipher] = '0';  // Set the first character to '0'
		return (number_str);  // Return the string
	}
	if (n < 0)  // If n is negative
	{
		n = -n;  // Make n positive
		number_str[0] = '-';  // Set the first character to '-'
	}
	number_str = str_numb(number_str, (unsigned int)n, cipher);  // Convert n to string and store it in number_str
	return (number_str);  // Return the resulting string
}
