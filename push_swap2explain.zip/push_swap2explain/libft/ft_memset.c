/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:10:35 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:11:27 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function fills the first 'len' bytes of the memory area pointed to by 'b'
// with the constant byte 'c'.
void *ft_memset(void *b, int c, size_t len)
{
    size_t			i; // Index variable for iteration
    char			*tmp; // Temporary pointer to the memory area
    unsigned char	tmpc; // Unsigned char representation of the fill byte

    i = 0; // Initialize the index 'i' to 0
    tmp = (char *)b; // Cast 'b' to a char pointer and assign it to 'tmp'
    tmpc = (unsigned char)c; // Convert the fill byte 'c' to unsigned char

    // Fill the memory area pointed to by 'tmp' with 'tmpc' for 'len' bytes
    while (i < len)
    {
        tmp[i] = tmpc;
        i++;
    }
    // Return a pointer to the memory area 'b'
    return (b);
}
