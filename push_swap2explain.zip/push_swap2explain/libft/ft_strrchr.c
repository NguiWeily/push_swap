/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:03:34 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:03:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function finds the last occurrence of character 'c' in string 's'.
char *ft_strrchr(const char *s, int c)
{
    int i; // Index variable for iteration

    i = ft_strlen(s); // Get the length of the string 's'

    // Iterate through the string 's' from the end to the beginning
    while (i >= 0)
    {
        // If the current character in 's' matches 'c', return a pointer to that character
        if (s[i] == (char)c)
            return ((char *)&s[i]);
        i--; // Move to the previous character in 's'
    }

    return (0); // Return NULL if 'c' is not found in 's'
}
