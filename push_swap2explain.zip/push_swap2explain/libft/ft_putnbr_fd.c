/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:44:16 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:44:21 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function writes the integer 'n' to the file descriptor 'fd'.
void ft_putnbr_fd(int n, int fd)
{
    // Check if 'n' is the minimum integer value, -2147483648.
    if (n == -2147483648)
    {
        // If 'n' is -2147483648, write '-' to the file descriptor 'fd'.
        ft_putchar_fd('-', fd);
        // Write '2' to the file descriptor 'fd'.
        ft_putchar_fd('2', fd);
        // Recursively call ft_putnbr_fd with the positive value 147483648 to write the remaining digits.
        ft_putnbr_fd(147483648, fd);
    }
    // Check if 'n' is negative.
    else if (n < 0)
    {
        // If 'n' is negative, write '-' to the file descriptor 'fd'.
        ft_putchar_fd('-', fd);
        // Recursively call ft_putnbr_fd with the positive value of 'n' to write the remaining digits.
        ft_putnbr_fd(-n, fd);
    }
    // Check if 'n' is a single digit.
    else if (n < 10)
        // If 'n' is a single digit, write 'n' converted to a character to the file descriptor 'fd'.
        ft_putchar_fd(n + '0', fd);
    else
    {
        // Recursively call ft_putnbr_fd with 'n' divided by 10 to write the digits before the last digit.
        ft_putnbr_fd(n / 10, fd);
        // Recursively call ft_putnbr_fd with 'n' modulo 10 to write the last digit.
        ft_putnbr_fd(n % 10, fd);
    }
}
