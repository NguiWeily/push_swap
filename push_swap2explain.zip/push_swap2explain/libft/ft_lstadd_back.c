/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:05:12 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:05:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_add_back adds a new element to the end of a linked list. It takes a pointer to a pointer to the list (alst) and a pointer to the new element (new). It first checks if the alst pointer is not NULL. If it is not NULL, it checks if the list is empty (*alst == NULL). If the list is empty, it sets the list to point to the new element. Otherwise, it traverses the list to find the last element and sets the next pointer of the last element to the new element.*/

void ft_add_back(t_list **alst, t_list *new)
{
	t_list *tmp;  // Temporary pointer to traverse the list

	if (alst)  // Check if the pointer to the pointer to the list is not NULL
	{
		if (*alst == NULL)  // If the list is empty
			*alst = new;  // Set the list to point to the new element
		else
		{
			tmp = ft_lstlast(*alst);  // Find the last element in the list
			tmp->next = new;  // Set the next pointer of the last element to the new element
		}
	}
}
