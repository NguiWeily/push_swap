/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:48:08 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:48:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_isprint checks if the given character c is a printable character. It does this by checking if the ASCII value of c is between 32 (space) and 126 (tilde), which are the printable ASCII characters in the ASCII table. If c is within this range, the function returns 1 (true), indicating that c is a printable character. Otherwise, it returns 0 (false), indicating that c is not a printable character.*/

int ft_isprint(int c)  // Function definition for ft_isprint that checks if a character is a printable character
{
    if (c > 31 && c < 127)  // Check if the ASCII value of the character corresponds to a printable character
        return (1);  // Return 1 (true) if the character is a printable character
    return (0);  // Return 0 (false) if the character is not a printable character
}
