/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:05:38 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:05:43 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function applies the function 'f' to each element of the linked list 'lst'
// and creates a new list with the results.
t_list *ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
    t_list *new_lst; // Pointer to the new list
    t_list *new_node; // Pointer to a new node
    t_list *orig; // Pointer to the original list

    new_lst = NULL; // Initialize the new list to NULL
    orig = lst; // Store a pointer to the original list
    // Loop through each node of the original list
    while (orig)
    {
        // Create a new node with the content modified by 'f'
        new_node = ft_stack_new(f(orig->content));
        // If allocation fails, clear the new list and return NULL
        if (!new_node)
        {
            ft_lstclear(&new_lst, del);
            return (NULL);
        }
        // Otherwise, add the new node to the end of the new list
        else
            ft_add_back(&new_lst, new_node);
        // Move to the next node of the original list
        orig = orig->next;
    }
    // Return the new list
    return (new_lst);
}
