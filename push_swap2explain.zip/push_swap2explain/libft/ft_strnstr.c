/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:52:35 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:52:38 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function finds the first occurrence of the substring 'needle' in the string 'haystack' up to 'len' characters.
char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    size_t i;   // Index variable for iterating through 'haystack'
    size_t i2;  // Index variable for iterating through 'needle'
    size_t tmp; // Temporary index variable for tracking the start of a potential match
    char *ret;  // Pointer to the result substring

    i = 0;      // Initialize the index 'i' to 0
    i2 = 0;     // Initialize the index 'i2' to 0
    tmp = 0;    // Initialize the temporary index 'tmp' to 0
    ret = NULL; // Initialize the result pointer 'ret' to NULL

    // Iterate through 'haystack' until the null terminator '\0' is reached or 'len' characters have been processed
    while (haystack[i] != '\0' && i < len)
    {
        // Iterate through 'haystack' and 'needle' while characters match and 'needle' is not fully matched or 'len' is not exceeded
        while (haystack[tmp] == needle[i2] && needle[i2] != '\0' && tmp < len)
        {
            tmp++;  // Move to the next character in 'haystack'
            i2++;   // Move to the next character in 'needle'
            // If the end of 'needle' is reached, return a pointer to the start of the match in 'haystack'
            if (needle[i2] == '\0')
                return ((char *)&haystack[i]);
        }
        i2 = 0; // Reset the index 'i2' to 0 for the next iteration
        i++;    // Move to the next character in 'haystack'
        tmp = i; // Reset the temporary index 'tmp' to the current index 'i'
    }

    // If 'needle' is an empty string, return a pointer to 'haystack'
    if (needle[i2] == '\0')
        return ((char *)haystack);

    // Return NULL if 'needle' is not found in 'haystack' within 'len' characters
    return (ret);
}
