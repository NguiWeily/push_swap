/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstlast.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:59:17 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:59:23 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function returns a pointer to the last node of a linked list.
t_list *ft_lstlast(t_list *lst)
{
    // Loop through the linked list until lst is NULL (end of the list).
    while (lst)
    {
        // If lst->next is NULL, then lst is the last node, so return lst.
        if (!lst->next)
            return (lst);
        // Move to the next node in the linked list.
        lst = lst->next;
    }
    // Return lst, which will be NULL if the linked list is empty.
    return (lst);
}
