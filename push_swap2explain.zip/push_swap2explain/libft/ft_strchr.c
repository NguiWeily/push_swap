/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:11:51 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:11:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function locates the first occurrence of character 'c' in string 's'.
char *ft_strchr(const char *s, int c)
{
    char *str; // Pointer to the character array 's'

    str = (char *)s; // Cast 's' to a char pointer and assign it to 'str'
    // Loop through each character in 'str' until 'c' is found or the end of the string ('\0') is reached.
    while (*str != (char)c)
    {
        // If the current character is '\0' (end of string), return NULL (character 'c' not found).
        if (*str == '\0')
        {
            return (NULL);
        }
        str++; // Move to the next character in 'str'
    }
    return (str); // Return a pointer to the first occurrence of 'c' in 's'.
}
