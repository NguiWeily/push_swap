/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:06:04 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:06:09 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function copies 'len' bytes from memory area 'src' to memory area 'dst',
// handling overlapping memory areas correctly.
void *ft_memmove(void *dst, const void *src, size_t len)
{
    unsigned char *dst2; // Pointer to the destination memory area
    unsigned char *src2; // Pointer to the source memory area

    // Cast 'dst' and 'src' to unsigned char pointers
    dst2 = (unsigned char *)dst;
    src2 = (unsigned char *)src;

    // If 'src' is located before 'dst' in memory (overlap),
    // adjust pointers to copy from end to beginning to avoid overwriting data.
    if (src < dst)
    {
        src2 = src2 + len - 1;
        dst2 = dst2 + len - 1;
        // Copy 'len' bytes from 'src' to 'dst' in reverse order
        while (len--)
            *dst2-- = *src2--;
    }
    // If 'src' is located after or at the same position as 'dst' in memory,
    // copy 'len' bytes from 'src' to 'dst' in forward order.
    else if (src >= dst)
    {
        // Copy 'len' bytes from 'src' to 'dst'
        while (len--)
            *dst2++ = *src2++;
    }

    // Return a pointer to the destination memory area
    return (dst);
}
