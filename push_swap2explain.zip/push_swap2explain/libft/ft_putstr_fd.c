/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:42:59 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:43:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function writes the string 's' to the file descriptor 'fd'.
void ft_putstr_fd(char *s, int fd)
{
    int i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0
    // Check if 's' is NULL or if 'fd' is less than 0, and return if either condition is true.
    if (!s || fd < 0)
        return ;
    // Loop through each character of the string 's' until the null terminator ('\0') is encountered.
    while (s[i])
    {
        // Write the current character of 's' to the file descriptor 'fd'.
        ft_putchar_fd(s[i], fd);
        // Move to the next character in 's'.
        i++;
    }
}
