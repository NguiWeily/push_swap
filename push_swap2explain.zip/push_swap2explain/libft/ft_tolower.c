/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:16:55 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:16:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function converts an uppercase letter to lowercase, if applicable.
int ft_tolower(int c)
{
    // Check if 'c' is an uppercase letter (ASCII values 65 to 90)
    if (c > 64 && c < 91)
        return (c + 32); // Convert the uppercase letter to lowercase and return it

    return (c); // Return 'c' unchanged if it is not an uppercase letter
}
