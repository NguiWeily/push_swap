/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:08:55 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:08:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_isalpha checks if the given character c is an alphabetic character. It does this by checking if the ASCII value of c corresponds to an uppercase letter (A to Z) or a lowercase letter (a to z). If c is within either of these ranges, the function returns 1 (true), indicating that c is an alphabetic character. Otherwise, it returns 0 (false), indicating that c is not an alphabetic character.*/

int ft_isalpha(int c)  // Function definition for ft_isalpha that checks if a character is an alphabetic character
{
    if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122))  // Check if the character is in the ASCII range for uppercase or lowercase letters
        return (1);  // Return 1 (true) if the character is an alphabetic character
    return (0);  // Return 0 (false) if the character is not an alphabetic character
}
