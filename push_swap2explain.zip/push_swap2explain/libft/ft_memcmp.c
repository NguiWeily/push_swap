/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:44:55 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:44:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function compares the first 'n' bytes of memory areas 's1' and 's2'.
int ft_memcmp(const void *s1, const void *s2, size_t n)
{
    size_t i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0
    // Loop through the memory areas until the end of the areas or until a difference is found
    while (i < n && ((unsigned char *)s1)[i] == ((unsigned char *)s2)[i])
        i++;
    // If 'i' is equal to 'n', all bytes are equal, so return 0
    if (i == n)
        return (0);
    // If a difference was found, return the difference between the first differing bytes
    return (((unsigned char *)s1)[i] - ((unsigned char *)s2)[i]);
}
