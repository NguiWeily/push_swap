/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:53:54 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:53:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./libft.h"

// This function extracts the next line from the 'rest' buffer and returns it.
char *ft_sub(char **rest, char **line)
{
    char *str; // Pointer to the newline character in 'rest'
    str = NULL; // Initialize 'str' to NULL

    if (*rest) // If 'rest' is not NULL (there is leftover from previous read)
    {
        *line = *rest; // Set 'line' to the rest of the string
        str = ft_strchr(*rest, '\n'); // Find the newline character in 'rest'
        if (str) // If newline character is found
        {
            str++; // Move 'str' to the next character after newline
            if (*str != '\0')
                *rest = ft_strdup(str); // Save the rest of the string in 'rest'
            else
                *rest = NULL; // If there is no rest, set 'rest' to NULL
            *str = '\0'; // Null-terminate 'line' at the newline character
        }
        else
            *rest = NULL; // If no newline character, set 'rest' to NULL
    }
    else // If 'rest' is NULL
    {
        *line = (char *)malloc(sizeof(char) * 1); // Allocate memory for an empty line
        *line[0] = '\0'; // Null-terminate the line
    }
    return (str); // Return 'str'
}

// This function reads from 'buf' and adds it to 'line', updating 'rest' with the remaining data.
char *ft_sub_2(char **rest, char **line, char **buf)
{
    char *str; // Pointer to the newline character in 'buf'
    char *tmp; // Temporary pointer for 'line'

    str = ft_strchr(*buf, '\n'); // Find the newline character in 'buf'
    if (str) // If newline character is found
    {
        str++; // Move 'str' to the next character after newline
        if (*str != '\0')
            *rest = ft_strdup(str); // Save the rest of the string in 'rest'
        *str = '\0'; // Null-terminate 'line' at the newline character
    }
    tmp = *line; // Save the current 'line' pointer
    *line = ft_strjoin(*line, *buf); // Concatenate 'line' and 'buf' and update 'line'
    free(tmp); // Free the old 'line' pointer
    return (str); // Return 'str'
}

// This function reads from a file descriptor 'fd' and returns the next line from the file.
char *get_next_line(int fd)
{
    char *buf; // Buffer for reading from file
    int i; // Number of bytes read
    char *str; // Pointer to newline character
    static char *rest[1024]; // Array to store leftover data from previous reads
    char *line; // Pointer to the current line

    // Check for invalid input or negative buffer size
    if (BUFFER_SIZE < 1 || read(fd, 0, 0) == -1 || fd < 0)
        return (NULL);

    buf = (char *)malloc(sizeof(char) * (BUFFER_SIZE + 1)); // Allocate memory for buffer
    if (!buf)
        return (NULL);

    str = ft_sub(&rest[fd], &line); // Extract the next line from 'rest' into 'line'

    i = 1; // Initialize 'i' to 1
    while (!str && i) // Continue reading until a newline character is found or 'i' is 0
    {
        i = read(fd, buf, BUFFER_SIZE); // Read from file into 'buf'
        buf[i] = '\0'; // Null-terminate 'buf'
        str = ft_sub_2(&rest[fd], &line, &buf); // Add 'buf' to 'line' and update 'rest'
    }

    free(buf); // Free the buffer
    if (ft_strlen(line) > 0)
        return (line); // Return 'line' if it contains data
    free (line); // Free 'line'
    return (NULL); // Return NULL if no data is read
}
