/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:51:23 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:51:28 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function concatenates two strings 's1' and 's2' and returns the result as a new string.
char *ft_strjoin(char const *s1, char const *s2)
{
    int i; // Index variable for iteration
    int len1; // Length of string 's1'
    int len2; // Length of string 's2'
    char *str; // Pointer to the concatenated string

    // Check if both 's1' and 's2' are not NULL
    if (s1 && s2)
    {
        // Calculate the lengths of 's1' and 's2' using ft_strlen
        len1 = ft_strlen(s1);
        len2 = ft_strlen(s2);
        // Allocate memory for the concatenated string based on the total length of 's1' and 's2' plus one for the null terminator
        str = (char *)malloc(sizeof(char) * (len1 + len2 + 1));
        // Check if memory allocation was successful
        if (str == NULL)
            return (NULL); // Return NULL if memory allocation failed

        // Copy characters from 's1' to 'str'
        i = -1;
        while (s1[++i])
            str[i] = s1[i];
        // Copy characters from 's2' to 'str', starting from the end of 's1'
        i = -1;
        while (s2[++i])
        {
            str[len1] = s2[i];
            len1++;
        }
        str[len1] = '\0'; // Add the null terminator at the end of the concatenated string
        return (str); // Return a pointer to the concatenated string
    }
    return (NULL); // Return NULL if either 's1' or 's2' is NULL
}
