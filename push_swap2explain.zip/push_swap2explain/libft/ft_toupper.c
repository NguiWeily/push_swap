/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:46:18 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:46:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function converts a lowercase letter to uppercase, if applicable.
int ft_toupper(int c)
{
    // Check if 'c' is a lowercase letter (ASCII values 97 to 122)
    if (c > 96 && c < 123)
        return (c - 32); // Convert the lowercase letter to uppercase and return it

    return (c); // Return 'c' unchanged if it is not a lowercase letter
}
