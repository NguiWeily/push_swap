/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yogun <yogun@student.42heilbronn.de>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 21:19:38 by yogun             #+#    #+#             */
/*   Updated: 2022/04/06 02:19:25 by yogun            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function applies the function 'f' to each character of the string 's', along with its index.
void ft_striteri(char *s, void (*f)(unsigned int, char*))
{
    unsigned int i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0
    // Check if 's' is NULL, and return if true (no operation to perform)
    if (!s)
        return ;
    // Loop through each character in 's' until the null terminator is reached
    while (s[i])
    {
        // Call the function 'f' with the current index 'i' and a pointer to the current character in 's'
        (*f)(i, s + i);
        i++; // Move to the next character in 's'
    }
}
