/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:12:50 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:12:53 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function creates a substring of length 'len' from string 's', starting at index 'start'.
char *ft_substr(const char *s, unsigned int start, size_t len)
{
    char *dst;      // Pointer to the substring
    int i;          // Index variable for iteration
    size_t len_s;   // Length of string 's'

    // Check if 's' is NULL, and return NULL if true
    if (!s)
        return (NULL);

    len_s = ft_strlen((const char *)s); // Get the length of string 's'

    // If 'len' is greater than the length of 's', set 'len' to the length of 's'
    if (len > len_s)
        len = len_s;

    // If 'start' is greater than or equal to the length of 's', return a new empty string
    if (start >= len_s)
        return ((char *)ft_calloc(sizeof(char), 1));

    i = 0; // Initialize the index 'i' to 0

    // Allocate memory for the substring 'dst' of length 'len' plus one for the null terminator
    dst = (char *)malloc((len + 1) * sizeof(char));

    // Check if memory allocation was successful
    if (!dst)
        return (NULL);

    // Copy characters from 's' to 'dst' starting at index 'start' until 'len' characters are copied or the end of 's' is reached
    while (len-- && s[i + (int)start])
    {
        dst[i] = s[i + start]; // Copy the current character from 's' to 'dst'
        i++; // Move to the next character in 's'
    }

    dst[i] = '\0'; // Add the null terminator at the end of the substring 'dst'

    return (dst); // Return a pointer to the substring 'dst'
}
