/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:12:30 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:12:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	"libft.h"

// This function calculates the length of the string 's' excluding the null terminator '\0'.
size_t ft_strlen(const char *s)
{
    int i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0

    // Loop through each character in 's' until the null terminator '\0' is encountered
    while (s[i])
    {
        i++; // Increment the index to move to the next character
    }

    return (i); // Return the total number of characters counted (excluding the null terminator '\0')
}
