/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:07:05 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:07:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function copies the string 'src' to 'dst' up to a maximum of 'size - 1' characters,
// ensuring that 'dst' is null-terminated.
size_t ft_strlcpy(char *dst, const char *src, size_t size)
{
    size_t i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0

    // If 'size' is 0, return the length of 'src' (not including the null terminator)
    if (!size)
        return (ft_strlen((const char *)src));

    // Copy characters from 'src' to 'dst' until the end of 'src' is reached or until 'size - 1' characters are copied
    while (src[i] && i < size - 1)
    {
        dst[i] = src[i]; // Copy the current character from 'src' to 'dst'
        i++; // Move to the next character
    }
    dst[i] = '\0'; // Add the null terminator at the end of 'dst'

    // Return the length of 'src' (not including the null terminator)
    return (ft_strlen((const char *)src));
}
