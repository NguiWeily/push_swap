/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:54:14 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:54:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_calloc is similar to the standard calloc function and is used to allocate and initialize a block of memory to zero. It first allocates memory using malloc, checks if the allocation was successful, initializes the memory block to zero using ft_bzero, and then returns a pointer to the allocated memory block.*/

void *ft_calloc(size_t count, size_t size)  // Function definition for ft_calloc that allocates and initializes memory
{
    void *ptr;  // Pointer to the allocated memory block

    ptr = malloc(count * size);  // Allocate memory for count * size bytes
    if (ptr == NULL)  // Check if malloc failed to allocate memory
        return (ptr);  // Return NULL if malloc failed
    ft_bzero(ptr, size * count);  // Initialize the allocated memory to zero
    return (ptr);  // Return a pointer to the allocated memory block
}
