/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:16:18 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:16:21 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function duplicates the string 's' in memory and returns a pointer to the duplicated string.
char *ft_strdup(const char *s)
{
    char *dest; // Pointer to the duplicated string
    int leng_s; // Length of the input string 's'
    int i; // Index variable for iteration

    // Calculate the length of the input string 's' using ft_strlen
    leng_s = ft_strlen((const char *)s);
    // Allocate memory for the duplicated string based on the length of 's' plus one for the null terminator
    dest = (char *)malloc(sizeof(char) * (leng_s + 1));
    // Check if memory allocation was successful
    if (!dest)
        return (NULL); // Return NULL if memory allocation failed

    i = 0; // Initialize the index 'i' to 0
    // Copy each character from 's' to 'dest' until the null terminator is reached
    while (s[i])
    {
        dest[i] = s[i];
        i++;
    }
    dest[i] = '\0'; // Add the null terminator to the end of the duplicated string
    return ((char *)dest); // Return a pointer to the duplicated string
}
