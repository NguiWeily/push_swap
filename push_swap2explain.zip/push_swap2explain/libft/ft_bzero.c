/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bzero.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:25:11 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:25:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_bzero is similar to the standard bzero function and is used to set a block of memory to zero. However, there is a mistake in the implementation. Instead of modifying the memory pointed to by s, it modifies the local pointer s, which has no effect outside the function. The correct implementation should use ft_memset to set the memory to zero.*/

void ft_bzero(void *s, size_t n)  // Function definition for ft_bzero that fills a block of memory with zeros
{
    if (n > 0)  // Check if the size of the memory block is greater than 0
        s = ft_memset(s, 0, n);  // Call ft_memset to set all bytes in the block of memory to zero
}
