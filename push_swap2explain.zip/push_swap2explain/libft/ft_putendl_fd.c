/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putendl_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:24:35 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:24:37 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function writes the string 's' followed by a newline ('\n') to the file descriptor 'fd'.
void ft_putendl_fd(char *s, int fd)
{
    // Check if 's' is NULL or if 'fd' is less than 0, and return if either condition is true.
    if (!s || fd < 0)
        return ;
    // Write the string 's' to the file descriptor 'fd' using ft_putstr_fd.
    ft_putstr_fd(s, fd);
    // Write a newline character ('\n') to the file descriptor 'fd' to move to the next line.
    write(fd, "\n", 1);
}
