/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstnew.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:10:13 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:10:19 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function creates a new element (node) for a linked list.
t_list *ft_lstnew(void *content)
{
    t_list *elt; // Pointer to the new element

    // Allocate memory for the new element
    elt = (t_list *)malloc(sizeof(*elt));
    // If allocation fails, return NULL
    if (!elt)
        return (NULL);
    // Set the content of the new element to the provided content
    elt->content = content;
    // Set the next pointer of the new element to NULL (end of the list)
    elt->next = NULL;
    // Return a pointer to the new element
    return (elt);
}
