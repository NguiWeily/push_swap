/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yogun <yogun@student.42heilbronn.de>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 21:23:35 by yogun             #+#    #+#             */
/*   Updated: 2022/04/05 21:23:40 by yogun            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_isdigit checks if the given character c is a digit. It does this by checking if the ASCII value of c is between 48 ('0') and 57 ('9'). If c is within this range, the function returns 1 (true), indicating that c is a digit. Otherwise, it returns 0 (false), indicating that c is not a digit.*/

int ft_isdigit(int c)  // Function definition for ft_isdigit that checks if a character is a digit
{
    if (c > 47 && c < 58)  // Check if the ASCII value of the character corresponds to a digit (0-9)
        return (1);  // Return 1 (true) if the character is a digit
    return (0);  // Return 0 (false) if the character is not a digit
}
