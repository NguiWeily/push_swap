/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelone.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:24:12 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:24:16 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_lstdelone deletes a single element from a linked list. It takes a pointer to the element to be deleted (lst) and a pointer to a function (del) that can delete the content of the element. It first checks if lst or del is NULL. If either is NULL, it returns without doing anything. Otherwise, it calls the del function to delete the content of lst and then frees the memory allocated for lst.*/

void ft_lstdelone(t_list *lst, void (*del)(void*))
{
	if (!lst || !del)  // Check if lst or del is NULL
		return ;  // If either is NULL, return without doing anything
	del(lst->content);  // Call the del function to delete the content of lst
	free(lst);  // Free the memory allocated for lst
}

