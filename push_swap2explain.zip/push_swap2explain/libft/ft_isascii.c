/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:14:27 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:14:30 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_isascii checks if the given character c is a valid ASCII character. It does this by checking if the value of c is within the valid ASCII range, which is from 0 to 127. If c is within this range, the function returns 1 (true), indicating that c is a valid ASCII character. Otherwise, it returns 0 (false), indicating that c is not a valid ASCII character.*/

int ft_isascii(int c)  // Function definition for ft_isascii that checks if a character is a valid ASCII character
{
    if (c >= 0 && c <= 127)  // Check if the character is within the valid ASCII range (0 to 127)
        return (1);  // Return 1 (true) if the character is a valid ASCII character
    return (0);  // Return 0 (false) if the character is not a valid ASCII character
}
