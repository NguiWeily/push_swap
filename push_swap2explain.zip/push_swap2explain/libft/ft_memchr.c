/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yogun <yogun@student.42heilbronn.de>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/04/05 20:46:35 by yogun             #+#    #+#             */
/*   Updated: 2022/04/05 21:23:02 by yogun            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function searches for the first occurrence of the character 'c' (converted to an unsigned char)
// in the first 'n' bytes of the memory area pointed to by 's'.
void *ft_memchr(const void *s, int c, size_t n)
{
    size_t			i; // Index variable for iteration
    unsigned char	*str; // Pointer to the memory area
    unsigned char	character; // The character to search for

    // Cast the input pointer 's' to an unsigned char pointer
    str = (unsigned char *)s;
    // Convert the character 'c' to unsigned char
    character = (unsigned char)c;
    // Initialize the index 'i' to 0
    i = 0;
    // Loop through the memory area until the end of the area or until 'n' bytes are processed
    while (i < n)
    {
        // If the current byte in memory matches the character we are searching for
        if (*str == character)
        {
            // Return a pointer to the location where the character was found
            return (str);
        }
        // Move to the next byte in memory
        str++;
        // Increment the index 'i'
        i++;
    }
    // If the character was not found in the memory area, return NULL
    return (NULL);
}
