/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar_fd.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:15:52 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:15:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function writes a character 'c' to the file descriptor 'fd'.
void ft_putchar_fd(char c, int fd)
{
    // Write the character 'c' to the file descriptor 'fd' using the write system call,
    // passing the address of 'c' and specifying that only 1 byte should be written.
    write(fd, &c, 1);
}
