/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:06:25 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:06:28 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function counts the number of words in a string 'str' delimited by the character 'c'.
static int count_words(const char *str, char c)
{
    int i; // Index variable for iteration
    int trigger; // Flag to track if a word has started

    i = 0; // Initialize the index 'i' to 0
    trigger = 0; // Initialize the trigger flag to 0
    // Loop through each character of the string 'str'
    while (*str)
    {
        // If the current character is not 'c' and the trigger flag is 0 (indicating the start of a word)
        if (*str != c && trigger == 0)
        {
            trigger = 1; // Set the trigger flag to 1 (indicating a word has started)
            i++; // Increment the word count
        }
        // If the current character is 'c', reset the trigger flag to 0 (indicating the end of a word)
        else if (*str == c)
            trigger = 0;
        str++; // Move to the next character in 'str'
    }
    return (i); // Return the total number of words counted
}

// This function duplicates a word from the string 'str' starting at index 'start' and ending at index 'finish'.
static char *word_dup(const char *str, int start, int finish)
{
    char *word; // Pointer to the duplicated word
    int i; // Index variable for iteration

    i = 0; // Initialize the index 'i' to 0
    // Allocate memory for the duplicated word based on the length of the word
    word = malloc((finish - start + 1) * sizeof(char));
    // Copy the characters of the word from 'str' to 'word'
    while (start < finish)
        word[i++] = str[start++];
    word[i] = '\0'; // Add the null terminator at the end of the word
    return (word); // Return the duplicated word
}

// This function splits a string 's' into an array of words delimited by the character 'c'.
char **ft_split(char const *s, char c)
{
    size_t i; // Index variable for iteration
    size_t j; // Index variable for array index
    int index; // Index variable to track the start of a word
    char **split; // Pointer to the array of split words

    // Allocate memory for the array of split words based on the count of words in 's'
    split = malloc((count_words(s, c) + 1) * sizeof(char *));
    if (!s || !split) // Check if 's' or 'split' is NULL, and return 0 if either is true
        return (0);
    i = 0; // Initialize the index 'i' to 0
    j = 0; // Initialize the index 'j' to 0
    index = -1; // Initialize the index 'index' to -1
    // Loop through each character of the string 's' including the null terminator
    while (i <= ft_strlen(s))
    {
        // If the current character is not 'c' and the index is negative (indicating the start of a new word)
        if (s[i] != c && index < 0)
            index = i; // Set the index to the current position
        // If the current character is 'c' or the end of 's' and the index is non-negative (indicating the end of a word)
        else if ((s[i] == c || i == ft_strlen(s)) && index >= 0)
        {
            // Duplicate the word from 's' starting at 'index' and ending at 'i'
            split[j++] = word_dup(s, index, i);
            index = -1; // Reset the index to -1
        }
        i++; // Move to the next character in 's'
    }
    split[j] = 0; // Add a null terminator at the end of the array of split words
    return (split); // Return the array of split words
}
