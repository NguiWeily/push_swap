/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:04:44 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:04:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_isalnum checks if the given character c is alphanumeric, which means it is either a digit or an alphabetic character. It uses the functions ft_isdigit and ft_isalpha to check if the character is not a digit and not an alphabetic character. If the character is neither, it returns 0 (false), indicating that the character is not alphanumeric. Otherwise, it returns 1 (true), indicating that the character is alphanumeric.*/

int ft_isalnum(int c)  // Function definition for ft_isalnum that checks if a character is alphanumeric
{
    if (ft_isdigit(c) == 0 && ft_isalpha(c) == 0)  // Check if the character is not a digit and not an alphabetic character
        return (0);  // Return 0 (false) if the character is not alphanumeric
    return (1);  // Return 1 (true) if the character is alphanumeric
}
