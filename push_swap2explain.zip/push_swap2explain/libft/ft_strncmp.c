/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:24:52 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:24:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function compares the first 'n' characters of two strings 's1' and 's2'.
// It returns an integer less than, equal to, or greater than 0 if 's1' is found,
// respectively, to be less than, to match, or be greater than 's2'.
int ft_strncmp(const char *s1, const char *s2, size_t n)
{
    // If 'n' is 0, return 0 (no characters to compare)
    if (n == 0)
    {
        return (0);
    }

    // Compare characters of 's1' and 's2' until a difference is found or 'n' characters have been compared
    while ((unsigned char)*s1 == (unsigned char)*s2 && *s1 != '\0' && n - 1 > 0)
    {
        s1++; // Move to the next character in 's1'
        s2++; // Move to the next character in 's2'
        n--;  // Decrement 'n' to track the number of characters left to compare
    }

    // Return the difference between the first differing characters of 's1' and 's2'
    return ((unsigned char)*s1 - (unsigned char)*s2);
}
