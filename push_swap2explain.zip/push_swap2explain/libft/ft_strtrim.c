/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:08:06 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:08:09 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function trims the characters specified in 'set' from the beginning and end of the string 's1'.
char *ft_strtrim(char const *s1, char const *set)
{
    size_t size_s;     // Length of the trimmed string
    char *newstring;   // Pointer to the trimmed string

    // Check if either 's1' or 'set' is NULL, and return NULL if true
    if (!s1 || !set)
        return (NULL);

    // Remove characters specified in 'set' from the beginning of 's1'
    while (*s1 && ft_strchr(set, *s1))
        s1++;

    // Calculate the length of the trimmed string 's1'
    size_s = ft_strlen(s1);

    // Remove characters specified in 'set' from the end of 's1'
    while (size_s && ft_strchr(set, s1[size_s]))
        size_s--;

    // Extract the trimmed substring from 's1' and store it in 'newstring'
    newstring = ft_substr((char *)s1, 0, size_s + 1);

    return (newstring); // Return a pointer to the trimmed string
}
