/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:16:36 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:16:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function applies the function 'f' to each character of the string 's' along with its index,
// and returns a new string with the results of the function applied to each character.
char *ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
    unsigned int i; // Index variable for iteration
    char *str; // Pointer to the new string

    // Check if 's' is NULL, and return NULL if true
    if (!s)
        return (NULL);

    i = 0; // Initialize the index 'i' to 0

    // Allocate memory for the new string 'str' based on the length of 's' plus one for the null terminator
    str = (char *)malloc(sizeof(char) * (ft_strlen(s)) + 1);

    // Check if memory allocation was successful
    if (str == NULL)
        return (NULL);

    // Loop through each character in 's' until the null terminator '\0' is encountered
    while (s[i] != '\0')
    {
        // Apply the function 'f' to the current character of 's' and its index 'i',
        // and store the result in the corresponding position of 'str'
        str[i] = f(i, s[i]);
        i++; // Move to the next character
    }

    str[i] = '\0'; // Add the null terminator at the end of 'str'

    return (str); // Return a pointer to the new string 'str'
}
