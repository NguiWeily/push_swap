/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 15:49:25 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 15:49:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function copies 'n' bytes from memory area 'src' to memory area 'dest'.
void *ft_memcpy(void *dest, const void *src, size_t n)
{
    unsigned char *pdest; // Pointer to the destination memory area
    unsigned char *psrc; // Pointer to the source memory area
    size_t i; // Index variable for iteration

    // If both 'dest' and 'src' are NULL, return NULL (no operation to perform)
    if (!dest && !src)
        return (NULL);
    // Cast 'dest' and 'src' to unsigned char pointers
    pdest = (unsigned char *)dest;
    psrc = (unsigned char *)src;
    i = 0; // Initialize the index 'i' to 0
    // Copy 'n' bytes from 'src' to 'dest'
    while (n--)
    {
        pdest[i] = psrc[i];
        i++;
    }
    // Return a pointer to the destination memory area
    return ((void *)dest);
}
