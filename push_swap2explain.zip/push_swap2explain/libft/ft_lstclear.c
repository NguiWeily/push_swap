/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:14:56 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:14:59 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_lstclear clears a linked list and frees the memory allocated for each element using the provided del function. It takes a pointer to a pointer to the list (lst) and a pointer to a function (del) that can delete an individual element. It iterates through the list, deleting each element and moving the list pointer to the next element, until it reaches the end of the list. Finally, it sets the list pointer to NULL to indicate that the list is now empty.*/

void ft_lstclear(t_list **lst, void (*del)(void*))
{
	t_list *next;  // Pointer to the next element in the list

	next = *lst;  // Initialize next to point to the first element in the list
	while (next)  // Loop until next is NULL (reached the end of the list)
	{
		next = next->next;  // Move next to the next element in the list
		ft_lstdelone(*lst, del);  // Delete the current element using the provided del function
		*lst = next;  // Move the list pointer to the next element
	}
	*lst = NULL;  // Set the list pointer to NULL to indicate that the list is now empty
}
