/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:23:51 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:23:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function takes a string str as input and converts it to an integer. It skips over any leading whitespace characters, handles the sign of the number, and converts each digit to an integer, accumulating the result. Finally, it returns the integer value with the correct sign.*/

int ft_atoi(const char *str)  // Function definition for ft_atoi that converts a string to an integer
{
    int res;  // Variable to store the result
    int isnegative;  // Flag to indicate if the number is negative
    int i;  // Counter variable for iterating through the string

    res = 0;  // Initialize result to 0
    i = 0;  // Initialize counter to 0
    isnegative = 0;  // Initialize isnegative flag to 0

    // Skip over any whitespace characters at the beginning of the string
    while ((str[i] <= 13 && str[i] >= 9) || str[i] == 32)
        i++;

    // Check if the number is negative
    if (str[i] == '-')
        isnegative = 1;

    // Skip over the sign character if present
    if (str[i] == '+' || str[i] == '-')
        i++;

    // Iterate through the string and convert each digit to an integer
    while (str[i] >= 48 && str[i] <= 57)
    {
        res *= 10;  // Multiply the result by 10 to shift digits left
        res += ((int)str[i] - 48);  // Add the value of the current digit to the result
        i++;  // Move to the next character in the string
    }

    // Return the result with the appropriate sign
    if (isnegative)
        return (-res);
    else
        return (res);
}
