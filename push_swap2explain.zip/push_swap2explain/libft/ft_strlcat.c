/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:00:19 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:00:22 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function concatenates the string 'src' to the end of the string 'dst', ensuring that the total length does not exceed 'dst_size'.
size_t ft_strlcat(char *dst, const char *src, size_t dst_size)
{
    size_t leng_dst; // Length of the destination string 'dst'
    size_t leng_src; // Length of the source string 'src'
    size_t i; // Index variable for iteration
    size_t limit; // Limit for the number of characters to copy from 'src' to 'dst'

    // Calculate the lengths of 'dst' and 'src' using ft_strlen
    leng_dst = ft_strlen(dst);
    leng_src = ft_strlen((const char *)src);
    
    // If 'dst_size' is less than or equal to the length of 'dst', return the sum of 'dst_size' and 'leng_src' (total length if 'src' were copied)
    if (dst_size <= leng_dst)
        return (dst_size + leng_src);

    // Initialize the index 'i' to 0 and the limit to the length of 'dst'
    i = 0;
    limit = leng_dst;

    // Copy characters from 'src' to 'dst' until the end of 'src' is reached or until 'dst' is full
    while (src[i] && i < (dst_size - leng_dst - 1))
        dst[limit++] = src[i++];

    dst[limit] = '\0'; // Add the null terminator at the end of the concatenated string in 'dst'

    // Return the total length of the concatenated string (length of 'dst' plus length of 'src')
    return (leng_dst + leng_src);
}
