/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstsize.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:15:27 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:15:29 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// This function returns the number of elements in a linked list.
int ft_lstsize(t_list *lst)
{
    int i; // Variable to store the number of elements

    i = 0; // Initialize i to 0
    // Loop through each node of the linked list until lst is NULL (end of the list)
    while (lst)
    {
        // Move to the next node in the linked list
        lst = lst->next;
        // Increment the count of elements
        i++;
    }
    // Return the total number of elements in the linked list
    return (i);
}
