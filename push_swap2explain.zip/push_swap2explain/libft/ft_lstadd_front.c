/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_front.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:09:47 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:09:51 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*This function ft_lstadd_front adds a new element to the beginning of a linked list. It takes a pointer to a pointer to the list (lst) and a pointer to the new element (new). It first checks if both lst and new are not NULL. If they are not NULL, it sets the next pointer of the new element to point to the current first element of the list (*lst), and then it sets the list pointer (*lst) to point to the new element, making it the new first element of the list.*/
void ft_lstadd_front(t_list **lst, t_list *new)
{
	if (lst && new)  // Check if both lst and new are not NULL
	{
		new->next = *lst;  // Set the next pointer of the new element to the current first element of the list
		*lst = new;  // Set the list pointer to point to the new element, making it the new first element
	}
}
