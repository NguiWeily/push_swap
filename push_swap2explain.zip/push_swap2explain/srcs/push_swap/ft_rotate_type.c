/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rotate_type.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:28:04 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:28:06 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function calculates and decides which rotation
// combination is best to use to sort the stack. Of
// course, after rotation, there is always one push
// operation left to do which is embedded in the code.
// The function is used during push from stack B to stack A.
int	ft_rotate_type_ba(t_stack *a, t_stack *b)
{
	int		i;
	t_stack	*tmp;

	// Initialize the minimum number of operations required to a very large value
	i = INT_MAX;
	// Start with the case where both stacks are rotated in reverse (rrarrb)
	tmp = b;
	while (tmp)
	{
		if (i > ft_case_rrarrb_a(a, b, tmp->nbr))
			i = ft_case_rrarrb_a(a, b, tmp->nbr);
		// Check other possible rotation combinations and update i if a better combination is found
		if (i > ft_case_rarb_a(a, b, tmp->nbr))
			i = ft_case_rarb_a(a, b, tmp->nbr);
		if (i > ft_case_rarrb_a(a, b, tmp->nbr))
			i = ft_case_rarrb_a(a, b, tmp->nbr);
		if (i > ft_case_rrarb_a(a, b, tmp->nbr))
			i = ft_case_rrarb_a(a, b, tmp->nbr);
		tmp = tmp->next;
	}
	// Return the minimum number of operations required
	return (i);
}


// This function calculates and decides which rotation
// combination is best to use to sort the stack. Of
// course, after rotation, there is always one push
// operation left to do which is embedded in the code.
// The function is used during push from stack A to stack B.
int	ft_rotate_type_ab(t_stack *a, t_stack *b)
{
	int		i;
	t_stack	*tmp;

	// Initialize the minimum number of operations required to a very large value
	i = INT_MAX;
	// Start with the case where stack A is rotated in reverse and stack B is rotated normally (rrarrb)
	tmp = a;
	while (tmp)
	{
		if (i > ft_case_rrarrb(a, b, tmp->nbr))
			i = ft_case_rrarrb(a, b, tmp->nbr);
		// Check other possible rotation combinations and update i if a better combination is found
		if (i > ft_case_rarb(a, b, tmp->nbr))
			i = ft_case_rarb(a, b, tmp->nbr);
		if (i > ft_case_rarrb(a, b, tmp->nbr))
			i = ft_case_rarrb(a, b, tmp->nbr);
		if (i > ft_case_rrarb(a, b, tmp->nbr))
			i = ft_case_rrarb(a, b, tmp->nbr);
		tmp = tmp->next;
	}
	// Return the minimum number of operations required
	return (i);
}

