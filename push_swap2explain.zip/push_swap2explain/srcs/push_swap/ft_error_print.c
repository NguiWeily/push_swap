/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_error_print.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:34:36 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:34:43 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// This function prints an error message to stderr and exits the program with a status of 1.
void	ft_error(void)
{
	write(2, "Error\n", 6); // write the error message "Error\n" to stderr (file descriptor 2)
	exit(1); // exit the program with a status of 1 (indicating an error)
}
