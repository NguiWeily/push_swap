/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:33:41 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:33:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

int	main(int argc, char **argv) // main function with command line arguments count and array
{
	t_stack	*a; // declare a variable 'a' of type t_stack (stack structure)

	a = ft_process(argc, argv); // parse command line arguments into a linked list 'a'
	if (!a || ft_checkdup(a)) // if 'a' is NULL or contains duplicate values
	{
		ft_free(&a); // free memory allocated for 'a'
		ft_error(); // call function to handle error
	}
	if (!ft_checksorted(a)) // if 'a' is not sorted
		ft_sort(&a); // sort 'a' using the push_swap algorithm
	ft_free(&a); // free memory allocated for 'a'
	return (0); // return 0 to indicate successful execution
}
