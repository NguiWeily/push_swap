/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_args_quoted.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:32:43 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:32:47 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function free the string which is 
// the integer values in between quotes.
void	ft_freestr(char **lst)
{
	char	*n1; // declare a variable to store the current string pointer

	if (!lst) // if lst is NULL, return immediately
		return ;
	while (*lst) // loop through each string pointer in the list until NULL is encountered
	{
		n1 = *lst; // store the current string pointer in n1
		lst++; // move to the next string pointer in the list
		free(n1); // free the memory allocated for the current string
	}
	*lst = NULL; // set the last string pointer in the list to NULL
}

// Function to parse the arguments from the quoted string
// and send them to list_args function to add them into list.
t_stack	*ft_parse_args_quoted(char **argv)
{
	t_stack	*stack_a; // declare a pointer to t_stack to store the stack
	char	**tmp; // declare a temporary string array to store the split arguments
	int		i; // declare variables for looping through arguments
	int		j;

	stack_a = NULL; // initialize stack_a to NULL
	i = 0; // initialize i to 0
	tmp = ft_split(argv[1], 32); // split the second argument (argv[1]) into an array of strings using space (' ') as a delimiter
	list_args(tmp, &stack_a); // parse the split arguments and add them to the stack
	ft_freestr(tmp); // free the memory allocated for the temporary string array
	free(tmp); // free the memory allocated for the temporary string array pointer
	return (stack_a); // return the stack
}

