/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:28:42 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:28:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// ra (rotate a): shift up all elements of stack a by 1.
// The first element becomes the last one.
void	ft_ra(t_stack **a, int j)
{
	// Check if stack a is empty or has only one element
	if (!*a || !(*a)->next)
		return ;
	// Save the current top element of stack a
	t_stack *tmp = *a;
	// Move to the last element of stack a
	*a = ft_lstlast(*a);
	// Make the last element point to the saved top element
	(*a)->next = tmp;
	// Move the new top element to the second position
	*a = tmp->next;
	// Set the next pointer of the original top element to NULL
	tmp->next = NULL;
	// If j is 0, print the operation as output
	if (j == 0)
		write(1, "ra\n", 3);
}

// sa (swap a): swap the first 2 elements at the top of stack a.
// Do nothing if there is only one or no elements.
void	ft_sa(t_stack **a, int j)
{
	// Check if stack a is empty or has only one element
	if (!*a || !((*a)->next))
		return ;
	// Save the top element of stack a
	t_stack *tmp = *a;
	// Move the top pointer to the second element
	*a = (*a)->next;
	// Swap the next pointers to perform the swap
	tmp->next = (*a)->next;
	(*a)->next = tmp;
	// If j is 0, print the operation as output
	if (j == 0)
		write(1, "sa\n", 3);
}

// pa (push a): take the first element at the top of b and
// put it at the top of a. Do nothing if b is empty.
void	ft_pa(t_stack **a, t_stack **b, int j)
{
	// Check if stack b is empty
	if (!*b)
		return ;
	// Save the current top element of stack a
	t_stack *tmp = *a;
	// Move the top pointer of stack a to the new top element from stack b
	*a = *b;
	// Move the top pointer of stack b to the next element
	*b = (*b)->next;
	// Link the new top element of stack a to the previous top element of stack a
	(*a)->next = tmp;
	// If j is 0, print the operation as output
	if (j == 0)
		write(1, "pa\n", 3);
}

// rra (reverse rotate a): shift down all elements of stack a by 1.
// The last element becomes the first one.
void	ft_rra(t_stack **a, int j)
{
	// Check if stack a is empty or has only one element
	if (!*a || !(*a)->next)
		return ;
	// Initialize a temporary pointer to the current top of stack a
	t_stack *tmp = *a;
	// Initialize a counter to keep track of the number of elements moved
	int i = 0;
	// Move the top pointer of stack a to the last element
	while ((*a)->next)
	{
		*a = (*a)->next;
		i++;
	}
	// Link the last element to the first element
	(*a)->next = tmp;
	// Move the tmp pointer to the element just before the new last element
	while (i > 1)
	{
		tmp = tmp->next;
		i--;
	}
	// Set the next pointer of the new last element to NULL
	tmp->next = NULL;
	// If j is 0, print the operation as output
	if (j == 0)
		write(1, "rra\n", 4);
}

// ss: sa and sb at the same time.
void	ft_ss(t_stack **a, t_stack **b, int j)
{
	// Check if stack a or b is empty, or if they have only one element
	if (!*a || !((*a)->next) || !*b || !((*b)->next))
		return ;
	// Swap the first 2 elements of stack a
	t_stack *tmp = *a;
	*a = (*a)->next;
	tmp->next = (*a)->next;
	(*a)->next = tmp;
	// Swap the first 2 elements of stack b
	tmp = *b;
	*b = (*b)->next;
	tmp->next = (*b)->next;
	(*b)->next = tmp;
	// If j is 0, print the operation as output
	if (j == 0)
		write(1, "ss\n", 3);
}