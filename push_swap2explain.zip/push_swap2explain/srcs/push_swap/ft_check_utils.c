/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:32:14 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:32:17 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// Function to check if the character is a sign ('+' or '-')
int	sign(int c)
{
	if (c == '+' || c == '-') // Check if the character is '+' or '-'
		return (1); // Return 1 if it is a sign character
	return (0); // Otherwise, return 0
}

// Function to check if the character is a digit (0-9)
int	digit(int c)
{
	if ((c >= 48) && (c <= 57)) // Check if the character is in the range of ASCII digits
		return (1); // Return 1 if it is a digit
	return (0); // Otherwise, return 0
}

// Function to check if the character is a space character (' ')
int	space(int c)
{
	if (c == ' ') // Check if the character is a space character
		return (1); // Return 1 if it is a space
	return (0); // Otherwise, return 0
}

// Function to check if the arguments are valid (no non-numeric characters except signs and spaces)
int	check_error(char **argv, int i, int j)
{
	while (argv[i]) // Loop through each argument
	{
		j = 0;
		while ((argv[i][j] != '\0')) // Loop through each character in the argument
		{
			if (sign(argv[i][j])) // If the character is a sign
			{
				j++;
				if (!digit(argv[i][j])) // Check if the next character is a digit
					return (false); // Return false if it's not a digit
			}
			else if (digit(argv[i][j])) // If the character is a digit
			{
				j++;
				if (argv[i][j] == '\0') // If it's the end of the argument
					break ; // Break out of the loop
				if (!digit(argv[i][j]) && !space(argv[i][j])) // Check if the next character is not a digit or space
					return (false); // Return false if it's not a digit or space
			}
			j++;
		}
		i++;
	}
	return (true); // Return true if all characters are valid
}
