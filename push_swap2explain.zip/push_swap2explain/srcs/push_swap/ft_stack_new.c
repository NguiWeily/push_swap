/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stack_new.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:37:43 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:37:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// Creates a new stack node with the given number.
t_stack	*ft_stack_new(int content)
{
	// Allocate memory for a new stack node
	t_stack	*new = malloc(sizeof(t_stack));
	// Check if memory allocation was successful
	if (!new)
		// If not, raise an error and exit
		ft_error();
	// Set the number of the new node
	new->nbr = content;
	// Set the next pointer of the new node to NULL
	new->next = NULL;
	// Return the new node
	return (new);
}

