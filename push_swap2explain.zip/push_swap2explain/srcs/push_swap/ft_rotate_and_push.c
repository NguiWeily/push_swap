/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rotate_and_push.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:37:19 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:37:23 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function rotates both stack_a and stack_b
// in the same direction as required amount.
// This function rotates both stack_a and stack_b
// in the same direction as required amount.
int	ft_apply_rarb(t_stack **a, t_stack **b, int c, char s)
{
	// If the operation is for stack_a
	if (s == 'a')
	{
		// Rotate stack_a and stack_b until the top element of stack_a is c and c is in the correct position in stack_b
		while ((*a)->nbr != c && ft_find_place_b(*b, c) > 0)
			ft_rr(a, b, 0);
		
		// Rotate stack_a until the top element of stack_a is c
		while ((*a)->nbr != c)
			ft_ra(a, 0);
		
		// Rotate stack_b until c is in the correct position in stack_b
		while (ft_find_place_b(*b, c) > 0)
			ft_rb(b, 0);
		
		// Push the top element of stack_a to stack_b
		ft_pb(a, b, 0);
	}
	// If the operation is for stack_b
	else
	{
		// Rotate stack_a and stack_b until the top element of stack_b is c and c is in the correct position in stack_a
		while ((*b)->nbr != c && ft_find_place_a(*a, c) > 0)
			ft_rr(a, b, 0);
		
		// Rotate stack_b until the top element of stack_b is c
		while ((*b)->nbr != c)
			ft_rb(b, 0);
		
		// Rotate stack_a until c is in the correct position in stack_a
		while (ft_find_place_a(*a, c) > 0)
			ft_ra(a, 0);
		
		// Push the top element of stack_b to stack_a
		ft_pa(a, b, 0);
	}
	
	// Return -1 as an indication of success
	return (-1);
}


/// This function rotate both stack_a and stack_b in the
// reverse direction as required amount.
int	ft_apply_rrarrb(t_stack **a, t_stack **b, int c, char s)
{
	// If the operation is for stack_a
	if (s == 'a')
	{
		// Rotate stack_a and stack_b in reverse until the top element of stack_a is c and c is in the correct position in stack_b
		while ((*a)->nbr != c && ft_find_place_b(*b, c) > 0)
			ft_rrr(a, b, 0);
		
		// Rotate stack_a in reverse until the top element of stack_a is c
		while ((*a)->nbr != c)
			ft_rra(a, 0);
		
		// Rotate stack_b in reverse until c is in the correct position in stack_b
		while (ft_find_place_b(*b, c) > 0)
			ft_rrb(b, 0);
		
		// Push the top element of stack_a to stack_b
		ft_pb(a, b, 0);
	}
	// If the operation is for stack_b
	else
	{
		// Rotate stack_a and stack_b in reverse until the top element of stack_b is c and c is in the correct position in stack_a
		while ((*b)->nbr != c && ft_find_place_a(*a, c) > 0)
			ft_rrr(a, b, 0);
		
		// Rotate stack_b in reverse until the top element of stack_b is c
		while ((*b)->nbr != c)
			ft_rrb(b, 0);
		
		// Rotate stack_a in reverse until c is in the correct position in stack_a
		while (ft_find_place_a(*a, c) > 0)
			ft_rra(a, 0);
		
		// Push the top element of stack_b to stack_a
		ft_pa(a, b, 0);
	}
	
	// Return -1 as an indication of success
	return (-1);
}

// This function rotate the stack_a in reverse direction,
// the stack_b in oppsite direction of stack_a as required amount.
int	ft_apply_rrarb(t_stack **a, t_stack **b, int c, char s)
{
	// If the operation is for stack_a
	if (s == 'a')
	{
		// Rotate stack_a in reverse until the top element of stack_a is c
		while ((*a)->nbr != c)
			ft_rra(a, 0);
		
		// Rotate stack_b in the opposite direction of stack_a until c is in the correct position in stack_b
		while (ft_find_place_b(*b, c) > 0)
			ft_rb(b, 0);
		
		// Push the top element of stack_a to stack_b
		ft_pb(a, b, 0);
	}
	// If the operation is for stack_b
	else
	{
		// Rotate stack_a in the opposite direction of stack_b until c is in the correct position in stack_a
		while (ft_find_place_a(*a, c) > 0)
			ft_rra(a, 0);
		
		// Rotate stack_b in reverse until the top element of stack_b is c
		while ((*b)->nbr != c)
			ft_rb(b, 0);
		
		// Push the top element of stack_b to stack_a
		ft_pa(a, b, 0);
	}
	
	// Return -1 as an indication of success
	return (-1);
}

// This function rotate the stack_b in reverse direction,
// the stack_a in oppsite direction of stack_a as required amount.
int	ft_apply_rarrb(t_stack **a, t_stack **b, int c, char s)
{
	// If the operation is for stack_a
	if (s == 'a')
	{
		// Rotate stack_a until the top element of stack_a is c
		while ((*a)->nbr != c)
			ft_ra(a, 0);
		
		// Rotate stack_b in reverse until c is in the correct position in stack_b
		while (ft_find_place_b(*b, c) > 0)
			ft_rrb(b, 0);
		
		// Push the top element of stack_a to stack_b
		ft_pb(a, b, 0);
	}
	// If the operation is for stack_b
	else
	{
		// Rotate stack_a in the opposite direction of stack_b until c is in the correct position in stack_a
		while (ft_find_place_a(*a, c) > 0)
			ft_ra(a, 0);
		
		// Rotate stack_b in reverse until the top element of stack_b is c
		while ((*b)->nbr != c)
			ft_rrb(b, 0);
		
		// Push the top element of stack_b to stack_a
		ft_pa(a, b, 0);
	}
	
	// Return -1 as an indication of success
	return (-1);
}

