/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solver_utils_ba.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:38:39 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:38:41 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function calculates the required amount of rotation.
// Calculations are done for ra+rb case.
int	ft_case_rarb_a(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to the number of rotations needed to bring element c to the top of stack a
	int	i = ft_find_place_a(a, c);

	// If the number of rotations needed to bring element c to the top of stack a is less than the number of rotations needed to bring element c to the top of stack b,
	// update i with the number of rotations needed to bring element c to the top of stack b
	if (i < ft_find_index(b, c))
		i = ft_find_index(b, c);

	// Return the total number of rotations needed
	return (i);
}

// This function calculates the required amount of rotation.
// Calculations are done for rra+rrb case.
int	ft_case_rrarrb_a(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the bottom of stack a
	if (ft_find_place_a(a, c))
		i = ft_lstsize(a) - ft_find_place_a(a, c);

	// Check if the number of rotations needed to bring element c to the bottom of stack a is less than the number of rotations needed to bring element c to the top of stack b,
	// and update i if necessary
	if ((i < (ft_lstsize(b) - ft_find_index(b, c))) && ft_find_index(b, c))
		i = ft_lstsize(b) - ft_find_index(b, c);

	// Return the total number of rotations needed
	return (i);
}

// This function calculates the required amount of rotation.
// Calculations are done for ra+rrb case.
int	ft_case_rarrb_a(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the top of stack b
	if (ft_find_index(b, c))
		i = ft_lstsize(b) - ft_find_index(b, c);

	// Calculate the total number of rotations needed
	i = ft_find_place_a(a, c) + i;

	// Return the total number of rotations needed
	return (i);
}

// This function calculates the required amount of rotation.
// Calculations are done for rra+rb case.
int	ft_case_rrarb_a(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the top of stack a
	if (ft_find_place_a(a, c))
		i = ft_lstsize(a) - ft_find_place_a(a, c);

	// Calculate the total number of rotations needed
	i = ft_find_index(b, c) + i;

	// Return the total number of rotations needed
	return (i);
}
