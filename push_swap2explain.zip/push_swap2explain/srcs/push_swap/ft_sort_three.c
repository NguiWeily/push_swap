/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_three.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:35:31 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:35:34 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function sorts the stack if there are only 
// three elements in the stack.
void	ft_sort_three(t_stack **stack_a)
{
	// If the minimum value is at the top of the stack
	if (ft_min(*stack_a) == (*stack_a)->nbr)
	{
		// Reverse rotate the stack (rra) and then swap the top two elements (sa)
		ft_rra(stack_a, 0);
		ft_sa(stack_a, 0);
	}
	// If the maximum value is at the top of the stack
	else if (ft_max(*stack_a) == (*stack_a)->nbr)
	{
		// Rotate the stack (ra) and if the stack is not sorted, swap the top two elements (sa)
		ft_ra(stack_a, 0);
		if (!ft_checksorted(*stack_a))
			ft_sa(stack_a, 0);
	}
	else
	{
		// If the maximum value is at the bottom of the stack, reverse rotate the stack (rra)
		// Otherwise, swap the top two elements (sa)
		if (ft_find_index(*stack_a, ft_max(*stack_a)) == 1)
			ft_rra(stack_a, 0);
		else
			ft_sa(stack_a, 0);
	}
}

