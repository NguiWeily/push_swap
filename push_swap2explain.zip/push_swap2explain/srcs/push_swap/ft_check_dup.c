/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_dup.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:36:41 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:36:45 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// This function checks if the stack contains any duplicate numbers.
// It iterates through the stack and compares each element with the rest of the elements.
// If a duplicate is found, it returns 1, otherwise it returns 0.
int	ft_checkdup(t_stack *a)
{
	t_stack	*tmp; // temporary pointer to traverse the stack

	while (a) // iterate through the stack until reaching the end
	{
		tmp = a->next; // set tmp to the next element after 'a'
		while (tmp) // iterate through the rest of the stack starting from tmp
		{
			if (a->nbr == tmp->nbr) // if 'a' and 'tmp' have the same value
				return (1); // return 1 to indicate duplicate found
			tmp = tmp->next; // move tmp to the next element
		}
		a = a->next; // move 'a' to the next element
	}
	return (0); // return 0 to indicate no duplicates found
}
