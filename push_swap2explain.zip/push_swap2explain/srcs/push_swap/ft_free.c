/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_free.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:36:58 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:37:01 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// This function frees the memory allocated for the stack.
void	ft_free(t_stack **lst)
{
	t_stack	*tmp; // temporary pointer to store the next element

	if (!lst) // if lst is NULL, return immediately
		return ;
	while (*lst) // iterate through the stack until reaching the end
	{
		tmp = (*lst)->next; // store the next element in tmp
		(*lst)->nbr = 0; // set the value of the current element to 0 (optional)
		free(*lst); // free the memory allocated for the current element
		*lst = tmp; // move to the next element
	}
}
