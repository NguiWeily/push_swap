/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_add_back.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:29:02 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:29:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// Function to add a new node to the stack from the back side
void	ft_add_back(t_stack **stack, t_stack *stack_new)
{
	// If the stack pointer is NULL, return immediately
	if (!stack)
		return ;
	// If the stack is empty, set the new node as the first node in the stack
	if (!*stack)
		*stack = stack_new;
	else
		(ft_lstlast(*stack))->next = stack_new; // Otherwise, find the last node in the stack and set its next pointer to the new node
}
