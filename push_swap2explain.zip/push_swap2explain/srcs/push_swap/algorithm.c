/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorithm.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:26:49 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:26:54 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// This function does three things.
// 1. It checks if the number of input is less than 2.
// 2. It checks if the number of input is equal to 2.
//    If it is, it means it is a quoted string.
// 3. It checks if the number of input is greater than 2.
//     If it is, it lists the arguements.
// This function converts a string to an integer.
// It skips whitespace characters and handles signs.
// If the result is out of range, it calls ft_error().
int	ft_atoi2(const char *str)
{
	int				mod; // modifier for sign
	long long int	i; // integer value

	i = 0;
	mod = 1;
	// Skip whitespace characters
	while (*str == ' ' || *str == '\t' || *str == '\n' || *str == '\f'
		|| *str == '\v' || *str == '\r')
		str++;
	// Handle sign
	if (*str == '-')
	{
		mod = -1;
		str++;
	}
	else if (*str == '+')
		str++;
	// Convert digits to integer
	while (*str)
	{
		if (!ft_isdigit(*str)) // if character is not a digit, call ft_error()
			ft_error();
		i = i * 10 + (*str - 48); // convert digit to integer
		str++;
	}
	// Check if result is within integer range
	if ((mod * i) > 2147483647 || (mod * i) < -2147483648)
		ft_error(); // call ft_error() if out of range
	return (mod * i); // return the integer value
}

// This function works and sorts the stacks
// in case of they are passed in between quotation
// marks. In this scenario, this function takes the
// string, and splits the numbers in order to create
// seperated integer number.
// This function processes quoted arguments.
// It splits the string into separate numbers and creates a linked list.
t_stack	*ft_sub_process(char **argv)
{
	t_stack	*a; // declare a variable 'a' of type t_stack (stack structure)
	char	**tmp; // temporary array for storing split strings
	int		i;
	int		j;

	a = NULL;
	i = 0;
	tmp = ft_split(argv[1], 32); // split the string into substrings at spaces
	while (tmp[i])
	{
		j = ft_atoi2(tmp[i]); // convert substring to integer
		ft_add_back(&a, ft_stack_new(j)); // add the integer to the linked list
		i++;
	}
	ft_freestr(tmp); // free memory allocated for the temporary array
	free(tmp);
	return (a); // return the linked list
}

// This function does three things.
// 1. It checks if the number of input is less than 2.
// 2. It checks if the number of input is equal to 2.
//    If it is, it means it is a quoted string. Call
//	  another function. <ft_sub_process>
// 3. It checks if the number of input is greater than 2.
//     If it is, it lists the arguements.
// This function processes arguments.
// It either calls ft_sub_process() for quoted arguments or adds each argument to the linked list.
t_stack	*ft_process(int argc, char **argv)
{
	t_stack	*a; // declare a variable 'a' of type t_stack (stack structure)
	int		i;
	int		j;

	i = 1;
	a = NULL;
	if (argc < 2) // if no arguments provided, call ft_error()
		ft_error();
	if (argc == 2) // if only one argument provided, process quoted arguments
		a = ft_sub_process(argv);
	else // if multiple arguments provided, process each argument
	{
		while (i < argc)
		{
			j = ft_atoi2(argv[i]); // convert argument to integer
			ft_add_back(&a, ft_stack_new(j)); // add integer to the linked list
			i++;
		}
	}
	return (a); // return the linked list
}
