/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_sorted.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:27:12 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:27:15 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// This function checks if the stack is sorted in ascending order.
// It returns 1 if the stack is sorted, 0 otherwise.
int	ft_checksorted(t_stack *stack_a)
{
	int	i; // variable to store the previous value

	i = stack_a->nbr; // initialize i with the value of the first element
	while (stack_a) // iterate through the stack
	{
		if (i > stack_a->nbr) // if the previous value is greater than the current value
			return (0); // return 0 to indicate stack is not sorted
		i = stack_a->nbr; // update the previous value
		stack_a = stack_a->next; // move to the next element
	}
	return (1); // return 1 to indicate stack is sorted
}
