/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_3.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:38:15 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:38:18 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// rb (rotate b) : shift up all elements of stack b by 1. 
// The first element becomes the last one.
void	ft_rb(t_stack **b, int j)
{
	// Check if stack b is empty or has only one element
	if (!*b || !(*b)->next)
		return ;

	// Initialize variables
	t_stack	*tmp = *b;

	// Move tmp to the last element of stack b
	*b = ft_lstlast(*b);

	// Move the first element to the last position
	(*b)->next = tmp;

	// Update the top of stack b to the second element
	*b = tmp->next;

	// Set the next pointer of the original first element to NULL
	tmp->next = NULL;

	// Output the operation if j is 0
	if (j == 0)
		write(1, "rb\n", 3);
}

// sb (swap b) : swap the first 2 elements at the top of stack b. 
// Do nothing if there is only one or no elements).
void	ft_sb(t_stack **b, int j)
{
	// Check if stack b is empty or has only one element
	if (!*b || !((*b)->next))
		return ;

	// Initialize a temporary pointer to the first element of stack b
	t_stack	*tmp = *b;

	// Move the top of stack b to the second element
	*b = (*b)->next;

	// Update the next pointer of the original top element to skip the new top element
	tmp->next = (*b)->next;

	// Move the original top element to the second position
	(*b)->next = tmp;

	// Output the operation if j is 0
	if (j == 0)
		write(1, "sb\n", 3);
}