/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lst_utils.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:33:21 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:33:23 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function returns the last element of the stack.
t_stack	*ft_lstlast(t_stack *lst)
{
	// If the stack is empty, return NULL
	if (!lst)
		return (NULL);
	// Traverse the stack to find the last element
	while (lst->next)
		lst = lst->next;
	// Return the last element of the stack
	return (lst);
}

// This function returns the size of the stack.
int	ft_lstsize(t_stack *lst)
{
	// Initialize a counter variable to 0
	size_t	i = 0;
	// Traverse the stack and increment the counter for each element
	while (lst)
	{
		lst = lst->next;
		i++;
	}
	// Return the total number of elements in the stack
	return (i);
}

// This function finds and returns the smallest number in the given stack.
int	ft_min(t_stack *a)
{
	// Initialize the minimum value with the first element of the stack
	int		i = a->nbr;
	// Traverse the stack and update the minimum value if a smaller number is found
	while (a)
	{
		if (a->nbr < i)
			i = a->nbr;
		// Move to the next element in the stack
		a = a->next;
	}
	// Return the smallest number
	return (i);
}

// This function finds and returns the biggest number in the given stack.
int	ft_max(t_stack *a)
{
	// Initialize the maximum value with the first element of the stack
	int		i = a->nbr;
	// Traverse the stack and update the maximum value if a larger number is found
	while (a)
	{
		if (a->nbr > i)
			i = a->nbr;
		// Move to the next element in the stack
		a = a->next;
	}
	// Return the biggest number
	return (i);
}
