/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lst_utils_2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:28:22 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:28:25 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function checks the index of a number in the stack.
int	ft_find_index(t_stack *a, int nbr)
{
	// Initialize the index variable to 0
	int		i = 0;
	// Traverse the stack until the number is found
	while (a->nbr != nbr)
	{
		// Increment the index counter
		i++;
		// Move to the next element in the stack
		a = a->next;
	}
	// Set the index of the found number
	a->index = 0;
	// Return the index of the number in the stack
	return (i);
}

// This function finds the correct place of the number in stack_b.
// It checks what index number nbr_push will get after it is pushed
// to stack_b.
int	ft_find_place_b(t_stack *stack_b, int nbr_push)
{
	// Initialize the index variable to 1
	int		i = 1;
	// Check if the number should be placed at the top of stack_b
	if (nbr_push > stack_b->nbr && nbr_push < ft_lstlast(stack_b)->nbr)
		i = 0;
	// Check if the number should be placed at the bottom of stack_b
	else if (nbr_push > ft_max(stack_b) || nbr_push < ft_min(stack_b))
		i = ft_find_index(stack_b, ft_max(stack_b));
	else
	{
		// Traverse the stack to find the correct position for nbr_push
		t_stack *tmp = stack_b->next;
		while (stack_b->nbr < nbr_push || tmp->nbr > nbr_push)
		{
			stack_b = stack_b->next;
			tmp = stack_b->next;
			i++;
		}
	}
	// Return the index where nbr_push should be placed in stack_b
	return (i);
}

// This function finds the correct place of the number in stack_a.
// It checks what index number nbr_push will get after it is pushed
// to stack_a.
int	ft_find_place_a(t_stack *stack_a, int nbr_push)
{
	// Initialize the index variable to 1
	int		i = 1;
	// Check if the number should be placed at the top of stack_a
	if (nbr_push < stack_a->nbr && nbr_push > ft_lstlast(stack_a)->nbr)
		i = 0;
	// Check if the number should be placed at the bottom of stack_a
	else if (nbr_push > ft_max(stack_a) || nbr_push < ft_min(stack_a))
		i = ft_find_index(stack_a, ft_min(stack_a));
	else
	{
		// Traverse the stack to find the correct position for nbr_push
		t_stack *tmp = stack_a->next;
		while (stack_a->nbr > nbr_push || tmp->nbr < nbr_push)
		{
			stack_a = stack_a->next;
			tmp = stack_a->next;
			i++;
		}
	}
	// Return the index where nbr_push should be placed in stack_a
	return (i);
}