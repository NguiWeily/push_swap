/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_args.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:34:06 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:34:09 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h" // include the push_swap.h header file from the specified path

// Function to check if a character is alphanumeric
int	ft_isalpha(int c)
{
	// Check if the character is in the range of alphanumeric ASCII values
	if ((c >= 58 && c <= 126) || (c >= 33 && c <= 42)
		|| (c == 44) || (c == 46) || (c == 47))
		return (1); // Return 1 if the character is alphanumeric
	return (0); // Otherwise, return 0
}

// Function to check if arguments contain any non-numeric characters
void	alpha_check(char **argv)
{
	int	i;
	int	j;

	i = 1;
	while (argv[i])
	{
		j = 0;
		while ((argv[i][j]) != '\0')
		{
			if (ft_isalpha(argv[i][j])) // Check if the character is alphanumeric
				ft_error(); // Call ft_error() if an alphanumeric character is found
			j++;
		}
		i++;
	}
}

// Function to check arguments for alphanumeric characters and other errors
int	check_args(char **argv)
{
	alpha_check(argv); // Check for alphanumeric characters in arguments
	if (!check_error(argv, 1, 0)) // Check for other errors in arguments
		return (false); // Return false if errors are found
	return (true); // Return true if arguments are valid
}
