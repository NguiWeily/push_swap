/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solver_utils_ab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:36:10 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:36:20 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function calculates how many times we should rotate the stacks together.
// Because after a certain amount of rotation, we will proceed only with one stack rotation.
int	ft_case_rarb(t_stack *a, t_stack *b, int c)
{
	// Find the number of rotations needed to bring the element c to the top of stack b
	int i = ft_find_place_b(b, c);

	// If the number of rotations needed for stack b is less than the number of rotations needed for stack a
	// Update the number of rotations to the number of rotations needed for stack a
	if (i < ft_find_index(a, c))
		i = ft_find_index(a, c);

	// Return the total number of rotations needed
	return (i);
}

// This function calculates how many times we should rotate the stacks together.
// Because after a certain amount of rotation, we will proceed only with one stack
// rotation. Since here we have reverse rotate, rather than index number,
// we check the reverse index number which is
// calculated by list_size - index_number.
int	ft_case_rrarrb(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the top of stack b
	// and update i with the reverse index number
	if (ft_find_place_b(b, c))
		i = ft_lstsize(b) - ft_find_place_b(b, c);

	// If the number of rotations needed for stack b is less than the number of rotations needed for stack a
	// Update the number of rotations to the number of rotations needed for stack a
	if ((i < (ft_lstsize(a) - ft_find_index(a, c))) && ft_find_index(a, c))
		i = ft_lstsize(a) - ft_find_index(a, c);

	// Return the total number of rotations needed
	return (i);
}

// Again, this function makes similar calculations.
// This function does the same calculations for the rra+rb case.
int	ft_case_rrarb(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the top of stack a in reverse
	// and update i with the reverse index number
	if (ft_find_index(a, c))
		i = ft_lstsize(a) - ft_find_index(a, c);

	// Add the number of rotations needed to bring element c to the top of stack b
	i = ft_find_place_b(b, c) + i;

	// Return the total number of rotations needed
	return (i);
}

// Again, this function makes similar calculations.
// This function does the same calculations for the ra+rrb case.
int	ft_case_rarrb(t_stack *a, t_stack *b, int c)
{
	// Initialize the number of rotations to 0
	int	i = 0;

	// Calculate the number of rotations needed to bring element c to the top of stack b in reverse
	// and update i with the reverse index number
	if (ft_find_place_b(b, c))
		i = ft_lstsize(b) - ft_find_place_b(b, c);

	// Add the number of rotations needed to bring element c to the top of stack a
	i = ft_find_index(a, c) + i;

	// Return the total number of rotations needed
	return (i);
}