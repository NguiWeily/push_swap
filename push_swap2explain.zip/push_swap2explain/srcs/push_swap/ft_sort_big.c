/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_big.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:33:02 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:33:04 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function sorts and pushes elements from stack_a to stack_b until only three elements are left in stack_a.
void	ft_sort_b_till_3(t_stack **stack_a, t_stack **stack_b)
{
	int		i; // variable to store rotation type
	t_stack	*tmp; // temporary pointer

	// Continue sorting and pushing until stack_a has 3 or fewer elements and is sorted
	while (ft_lstsize(*stack_a) > 3 && !ft_checksorted(*stack_a))
	{
		tmp = *stack_a; // store the current top element of stack_a
		i = ft_rotate_type_ab(*stack_a, *stack_b); // determine the rotation type to push elements to stack_b
		while (i >= 0)
		{
			// Check different rotation cases and apply the corresponding operation
			if (i == ft_case_rarb(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rarb(stack_a, stack_b, tmp->nbr, 'a');
			else if (i == ft_case_rrarrb(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rrarrb(stack_a, stack_b, tmp->nbr, 'a');
			else if (i == ft_case_rarrb(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rarrb(stack_a, stack_b, tmp->nbr, 'a');
			else if (i == ft_case_rrarb(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rrarb(stack_a, stack_b, tmp->nbr, 'a');
			else
				tmp = tmp->next; // move to the next element if no rotation is needed
		}
	}
}

// This function sequentially pushes elements from stack_a to stack_b until only three elements are left in stack_a.
// It ensures that stack_b is sorted while pushing elements.
t_stack	*ft_sort_b(t_stack **stack_a)
{
	t_stack	*stack_b; // declare a variable 'stack_b' of type t_stack (stack structure)

	stack_b = NULL; // initialize stack_b to NULL
	// Push elements to stack_b if stack_a has more than 3 elements and is not sorted
	if (ft_lstsize(*stack_a) > 3 && !ft_checksorted(*stack_a))
		ft_pb(stack_a, &stack_b, 0);
	if (ft_lstsize(*stack_a) > 3 && !ft_checksorted(*stack_a))
		ft_pb(stack_a, &stack_b, 0);
	if (ft_lstsize(*stack_a) > 3 && !ft_checksorted(*stack_a))
		ft_sort_b_till_3(stack_a, &stack_b); // sort stack_a until only 3 elements are left
	if (!ft_checksorted(*stack_a)) // if stack_a is still not sorted after pushing elements to stack_b
		ft_sort_three(stack_a); // sort the remaining elements in stack_a
	return (stack_b); // return stack_b
}

// This function sequentially pushes elements back from stack_b to stack_a until stack_b is empty.
t_stack	**ft_sort_a(t_stack **stack_a, t_stack **stack_b)
{
	int		i; // variable to store rotation type
	t_stack	*tmp; // temporary pointer

	while (*stack_b) // continue until stack_b is empty
	{
		tmp = *stack_b; // store the current top element of stack_b
		i = ft_rotate_type_ba(*stack_a, *stack_b); // determine the rotation type to push elements back to stack_a
		while (i >= 0)
		{
			// Check different rotation cases and apply the corresponding operation
			if (i == ft_case_rarb_a(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rarb(stack_a, stack_b, tmp->nbr, 'b');
			else if (i == ft_case_rarrb_a(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rarrb(stack_a, stack_b, tmp->nbr, 'b');
			else if (i == ft_case_rrarrb_a(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rrarrb(stack_a, stack_b, tmp->nbr, 'b');
			else if (i == ft_case_rrarb_a(*stack_a, *stack_b, tmp->nbr))
				i = ft_apply_rrarb(stack_a, stack_b, tmp->nbr, 'b');
			else
				tmp = tmp->next; // move to the next element if no rotation is needed
		}
	}
	return (stack_a); // return stack_a
}

// This function sorts the stack_a.
// It first pushes elements to stack_b and sorts them there,
// then pushes them back to stack_a, ensuring that stack_a is sorted at the end.
void	ft_sort(t_stack **stack_a)
{
	t_stack	*stack_b; // declare a variable 'stack_b' of type t_stack (stack structure)
	int		i; // variable to store index

	stack_b = NULL; // initialize stack_b to NULL
	if (ft_lstsize(*stack_a) == 2) // if stack_a has 2 elements, perform sa operation to sort them
		ft_sa(stack_a, 0);
	else
	{
		stack_b = ft_sort_b(stack_a); // sort stack_a by pushing elements to stack_b
		stack_a = ft_sort_a(stack_a, &stack_b); // push elements back to stack_a from stack_b
		i = ft_find_index(*stack_a, ft_min(*stack_a)); // find the index of the smallest element in stack_a
		if (i < ft_lstsize(*stack_a) - i) // if the smallest element is closer to the top of stack_a
		{
			while ((*stack_a)->nbr != ft_min(*stack_a)) // rotate stack_a until the smallest element is at the top
				ft_ra(stack_a, 0);
		}
		else // if the smallest element is closer to the bottom of stack_a
		{
			while ((*stack_a)->nbr != ft_min(*stack_a)) // reverse rotate stack_a until the smallest element is at the top
				ft_rra(stack_a, 0);
		}
	}
}
