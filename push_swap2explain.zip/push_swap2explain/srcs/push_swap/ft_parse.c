/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:35:11 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:35:13 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function does three things.
// 1. It checks if the number of input is less than 2.
// 2. It checks if the number of input is equal to 2.
//    If it is, it means it is a quoted string.
// 3. It checks if the number of input is greater than 2.
//     If it is, it lists the arguements.
t_stack	*ft_parse(int argc, char **argv)
{
	t_stack	*stack_a; // declare a pointer to t_stack to store the stack
	int		i; // declare variables for looping through arguments
	int		j;

	i = 1; // initialize i to 1 (skipping the program name)
	stack_a = NULL; // initialize stack_a to NULL
	if (argc < 2) // if there are less than 2 arguments (excluding the program name)
		ft_error(); // call ft_error() function to handle the error
	else if (argc == 2) // if there are 2 arguments (including the program name)
		stack_a = ft_parse_args_quoted(argv); // parse the arguments as a quoted string
	else // if there are more than 2 arguments
	{
		list_args(argv, &stack_a); // parse the arguments as separate numbers and add them to the stack
	}
	return (stack_a); // return the stack
}
