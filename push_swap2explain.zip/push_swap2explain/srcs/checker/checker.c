/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42mail.sutd.edu.sg>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 10:53:46 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 10:54:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

// This function is the second part of the ft_check function.
void	ft_check_sub(t_stack **a, t_stack **b, char *line)
{
	// Check if the command is to reverse rotate stack a
	if (line[2] == 'a')
		ft_rra(a, 1);
	// Check if the command is to reverse rotate stack b
	else if (line[2] == 'b')
		ft_rrb(b, 1);
	// Check if the command is to reverse rotate both stacks
	else if (line[2] == 'r')
		ft_rrr(a, b, 1);
}

/// This function reads the line and checks if the command is valid.
// If it is, it executes the command.
char	*ft_check(t_stack **a, t_stack **b, char *line)
{
	// Check if the command is swap a (sa)
	if (line[0] == 's' && line[1] == 'a' && line[2] == '\n')
		ft_sa(a, 1);
	// Check if the command is swap b (sb)
	else if (line[0] == 's' && line[1] == 'b' && line[2] == '\n')
		ft_sb(b, 1);
	// Check if the command is push a (pa)
	else if (line[0] == 'p' && line[1] == 'a' && line[2] == '\n')
		ft_pa(a, b, 1);
	// Check if the command is push b (pb)
	else if (line[0] == 'p' && line[1] == 'b' && line[2] == '\n')
		ft_pb(a, b, 1);
	// Check if the command is rotate a (ra)
	else if (line[0] == 'r' && line[1] == 'a' && line[2] == '\n')
		ft_ra(a, 1);
	// Check if the command is rotate b (rb)
	else if (line[0] == 'r' && line[1] == 'b' && line[2] == '\n')
		ft_rb(b, 1);
	// Check if the command is reverse rotate both stacks (rrr)
	else if (line[0] == 'r' && line[1] == 'r' && line[3] == '\n')
		ft_check_sub(a, b, line);
	// Check if the command is rotate both stacks (rr)
	else if (line[0] == 'r' && line[1] == 'r' && line[2] == '\n')
		ft_rr(a, b, 1);
	// Check if the command is swap both stacks (ss)
	else if (line[0] == 's' && line[1] == 's' && line[2] == '\n')
		ft_ss(a, b, 1);
	else
		ft_error_ch(); // Error if the command is invalid
	return (get_next_line(0)); // Read the next line
}

// This function checks the validity of the commands and stack.
// If it is valid, and the stack_a is sorted, the program prints "OK".
void	ft_checker_sub(t_stack **a, t_stack **b, char *line)
{
	char	*tmp;

	// Loop through each character in the line until the end of the line or null character
	while (line && *line != '\n')
	{
		tmp = line; // Store the current position in the line
		line = ft_check(a, b, line); // Check and execute the command at the current position
		free(tmp); // Free the memory allocated for the command
	}

	// Check if stack b is not empty, indicating that the sorting is incorrect
	if (*b)
		write(1, "KO\n", 3);
	// Check if stack a is not sorted, indicating that the sorting is incorrect
	else if (!ft_checksorted(*a))
		write(1, "KO\n", 3);
	else
		write(1, "OK\n", 3); // Print "OK" if the stack is sorted correctly
	free(line); // Free the memory allocated for the line
}

int	main(int argc, char **argv)
{
	t_stack	*a;
	t_stack	*b;
	char	*line;

	b = NULL; // Initialize stack b as empty
	a = ft_process(argc, argv); // Process the arguments and create stack a
	// Check if stack a is NULL (indicating an error) or if there are duplicate numbers
	if (!a || ft_checkdup(a))
	{
		ft_free(&a); // Free the memory allocated for stack a
		ft_error_ch(); // Print an error message and exit the program
	}
	line = get_next_line(0); // Read the next line of input
	// Check if there is no input line and stack a is not sorted
	if (!line && !ft_checksorted(a))
		write(1, "KO\n", 3); // Print "KO" (not okay) indicating the stack is not sorted
	// Check if there is no input line and stack a is sorted
	else if (!line && ft_checksorted(a))
		write(1, "OK\n", 3); // Print "OK" (okay) indicating the stack is sorted
	else
		ft_checker_sub(&a, &b, line); // Check the validity of the commands and stack
	ft_free(&b); // Free the memory allocated for stack b
	ft_free(&a); // Free the memory allocated for stack a
	return (0); // Exit the program with success status
}