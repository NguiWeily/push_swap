/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 16:18:31 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 16:18:35 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/push_swap.h"

void	ft_error_ch(void)
{
	write(1, "Error\n", 6); // Print "Error" message to stdout
	exit(EXIT_FAILURE); // Exit the program with failure status
}
