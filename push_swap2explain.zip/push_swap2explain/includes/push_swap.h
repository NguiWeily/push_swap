/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/22 13:22:56 by wngui             #+#    #+#             */
/*   Updated: 2024/02/22 13:23:05 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H // if PUSH_SWAP_H is not defined
# define PUSH_SWAP_H // define PUSH_SWAP_H

# include <unistd.h> // include the library for write, read, and close functions
# include <stddef.h> // include the library for size_t and NULL
# include <stdio.h> // include the library for standard input/output operations
# include <stdlib.h> // include the library for standard library functions
# include <stdbool.h> // include the library for boolean types
# include <limits.h> // include the library for INT_MAX
# include "../libft/libft.h" // include the custom library libft.h from the specified path

typedef struct s_stack // define a struct named s_stack
{
	long			nbr; // integer value in the node
	long			index; // index of the node
	struct s_stack	*next; // pointer to the next node
	struct s_stack	*prev; // pointer to the previous node
}	t_stack; // alias for struct s_stack as t_stack

// function prototypes
void		list_args(char **argv, t_stack **stack_a); // function to create a linked list from arguments
void		ft_add_back(t_stack **stack, t_stack *stack_new); // function to add a node to the end of a linked list
t_stack		*ft_stack_new(int content); // function to create a new node for the linked list
int			check_args(char **argv); // function to check the validity of arguments
void		alpha_check(char **argv); // function to check for alphabetical characters in arguments
int			check_error(char **argv, int i, int j); // function to check for errors in arguments
int			ft_checkdup(t_stack *a); // function to check for duplicate values in the stack
int			ft_isalpha(int c); // function to check if a character is alphabetic
int			sign(int c); // function to check if a character is a sign (+/-)
int			digit(int c); // function to check if a character is a digit
int			space(int c); // function to check if a character is a space
void		ft_error(void); // function to handle errors
void		ft_free(t_stack **lst); // function to free memory allocated for a linked list
t_stack		*ft_lstlast(t_stack *lst); // function to get the last node of a linked list
void		ft_ra(t_stack **a, int j); // function to rotate the stack a
void		ft_rb(t_stack **b, int j); // function to rotate the stack b
void		ft_sa(t_stack **a, int j); // function to swap the top two elements of stack a
void		ft_pa(t_stack **a, t_stack **b, int j); // function to push the top element of stack b to stack a
void		ft_pb(t_stack **stack_a, t_stack **stack_b, int j); // function to push the top element of stack a to stack b
void		ft_rra(t_stack **a, int j); // function to reverse rotate the stack a
void		ft_ss(t_stack **a, t_stack **b, int j); // function to perform ss operation (sa and sb)
void		ft_rr(t_stack **a, t_stack **b, int j); // function to perform rr operation (ra and rb)
void		ft_rrr_sub(t_stack **b, int j); // helper function for rrr operation
void		ft_rrr(t_stack **a, t_stack **b, int j); // function to perform rrr operation (rra and rrb)
t_stack		*ft_lstlast(t_stack *lst); // function to get the last node of a linked list
int			ft_lstsize(t_stack *lst); // function to get the size of a linked list
int			ft_min(t_stack *a); // function to find the minimum value in stack a
int			ft_max(t_stack *a); // function to find the maximum value in stack a
int			ft_find_index(t_stack *a, int nbr); // function to find the index of a given value in stack a
int			ft_find_place_b(t_stack *stack_b, int nbr_push); // function to find the correct place to push a value in stack b
int			ft_find_place_a(t_stack *a, int nbr); // function to find the correct place to push a value in stack a
void		ft_sort(t_stack **stack_a); // function to sort the stack using the push_swap algorithm
int			ft_checksorted(t_stack *stack_a); // function to check if the stack is sorted
void		ft_sort_big(t_stack **stack_a); // function to sort a big stack using the push_swap algorithm
void		ft_sort_three(t_stack **stack_a); // function to sort three elements in stack a
t_stack		*ft_parse(int argc, char **argv); // function to parse arguments into a linked list
t_stack		*ft_parse_args_quoted(char **argv); // function to parse quoted arguments into a linked list
void		ft_freestr(char **lst); // function to free memory allocated for a string
int			ft_case_rarb_a(t_stack *a, t_stack *b, int c); // function to check case rarb for stack a
int			ft_case_rrarrb_a(t_stack *a, t_stack *b, int c); // function to check case rrarrb for stack a
int			ft_case_rarrb_a(t_stack *a, t_stack *b, int c); // function to check case rarrb for stack a
int			ft_case_rrarb_a(t_stack *a, t_stack *b, int c); // function to check case rrarb for stack a
int			ft_case_rarb(t_stack *a, t_stack *b, int c); // function to check case rarb for stack a and b
int			ft_case_rrarrb(t_stack *a, t_stack *b, int c); // function to check case rrarrb for stack a and b
int			ft_case_rrarb(t_stack *a, t_stack *b, int c); // function to check case rrarb for stack a and b
int			ft_case_rarrb(t_stack *a, t_stack *b, int c); // function to check case rarrb for stack a and b
int			ft_rotate_type_ab(t_stack *a, t_stack *b); // function to determine the rotation type for stack a and b
int			ft_rotate_type_ba(t_stack *a, t_stack *b); // function to determine the rotation type for stack b and a
int			ft_apply_rarb(t_stack **a, t_stack **b, int c, char s); // function to apply rarb operation
int			ft_apply_rrarrb(t_stack **a, t_stack **b, int c, char s); // function to apply rrarrb operation
int			ft_apply_rrarb(t_stack **a, t_stack **b, int c, char s); // function to apply rrarb operation
int			ft_apply_rarrb(t_stack **a, t_stack **b, int c, char s); // function to apply rarrb operation
void		ft_rrb(t_stack **b, int j); // function to reverse rotate the stack b
void		ft_check_sub(t_stack **a, t_stack **b, char *line); // helper function for ft_check
char		*ft_check(t_stack **a, t_stack **b, char *line); // function to check and execute a single operation
void		ft_checker_sub(t_stack **a, t_stack **b, char *line); // helper function for ft_checker
t_stack		*ft_process(int argc, char **argv); // function to process arguments for checker program
void		ft_sb(t_stack **b, int j); // function to swap the top two elements of stack b
void		algorithm(int argc, char **argv); // main algorithm function for push_swap program
void		ft_sort_b_till_3(t_stack **stack_a, t_stack **stack_b); // function to sort stack b until it has 3 or fewer elements
t_stack		*ft_sub_process(char **argv); // function to process arguments for sub-checker program
void		ft_error_ch(void); // function to handle errors for checker program

#endif // end of ifndef PUSH_SWAP_H
