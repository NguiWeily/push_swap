/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algorithm.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:21:32 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:21:36 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	algorithm(t_pushSwap piles)
{
	if (pile_size(piles, piles.a) == 0 || pile_size(piles, piles.a) == 1)
		return ;
	else if (pile_size(piles, piles.a) == 2)
		algo_2_elements_a(piles);
	else if (pile_size(piles, piles.a) == 3)
		algo_3_elements_a(piles);
	else if (pile_size(piles, piles.a) < 20)
		algo_19_elements_a(piles);
	else if (pile_size(piles, piles.a) < 251)
		algo_250_elements_a(piles);
	else if (pile_size(piles, piles.a) < 751)
		algo_750_elements_a(piles);
	else
		algo_blocs(piles, 50);
}
