/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:34:13 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:34:18 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	push_swap(char **args, int size)
{
	t_pushSwap	piles;

	piles = get_piles(args, size);
	if (!(piles.a) || !(piles.b))
		return (0);
	piles = duplicate_piles(piles);
	piles.operations = malloc(sizeof(t_operation));
	if (!(piles.operations))
	{
		ft_putstr_fd(ERR_ALLOC, 2);
		return (free(piles.a), free(piles.b), 0);
	}
	piles.operations->operation = NONE;
	piles.operations->next = NULL;
	if (!pile_sorted(piles, piles.a))
		algorithm(piles);
	free(piles.a);
	free(piles.b);
	optimise_operations(piles);
	print_operations(piles);
	free_operations(piles);
	return (free(piles.original_a), free(piles.original_b), 1);
}

int	main(int argc, char **argv)
{
	if (argc == 1)
		return (1);
	else if (!push_swap(argv + 1, argc - 1))
		return (1);
	return (0);
}
