/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_arguments_size.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:21:52 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:21:56 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	check_arguments_size(char **args, int size)
{
	int	i;

	i = 0;
	while (i < size)
	{
		if (ft_strlen(args[i]) == 0)
			return (ft_putstr_fd(ERR_WRONGTYPEARGS, 2), 0);
		i++;
	}
	return (1);
}
