/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   actions.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:20:36 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:20:39 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h" 

void	actions_smallest_on_top_a(t_pushSwap piles)
{
	push_b(piles);
}

void	actions_sec_smallest_on_top_a(t_pushSwap piles)
{
	t_numbers	numbers;

	push_b(piles);
	numbers = define_properties(piles, piles.a);
	place_element_on_top_a(piles, numbers.smallest);
	push_b(piles);
	swap_b(piles);
}

void	actions_biggest_on_top_a(t_pushSwap piles)
{
	push_b(piles);
	rotate_b(piles);
}
