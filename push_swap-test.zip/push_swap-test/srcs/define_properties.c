/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   define_properties.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:22:55 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:22:58 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

t_numbers	define_properties(t_pushSwap piles, t_elem *pile)
{
	t_numbers	numbers;

	numbers.smallest = find_smallest(piles, pile);
	numbers.sec_smallest = find_sec_smallest(piles, pile);
	numbers.biggest = find_biggest(piles, pile);
	numbers.sec_biggest = find_sec_biggest(piles, pile);
	numbers.ontop = find_ontop(piles, pile);
	numbers.nearest = find_nearest(piles, pile, numbers);
	return (numbers);
}
