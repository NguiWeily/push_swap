/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pile_sorted.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:32:30 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:32:33 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	pile_sorted(t_pushSwap piles, t_elem *pile)
{
	int	i;

	i = 0;
	while (i < piles.size)
	{
		if ((pile + i)->index != EMPTY)
			break ;
		i++;
	}
	while (i < piles.size)
	{
		i++;
		if (i < piles.size && (pile + i)->index < (pile + i - 1)->index)
			return (0);
	}
	return (1);
}
