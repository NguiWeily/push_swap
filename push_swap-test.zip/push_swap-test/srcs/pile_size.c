/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pile_size.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/10 16:32:08 by wngui             #+#    #+#             */
/*   Updated: 2024/02/10 16:32:11 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	pile_size(t_pushSwap piles, t_elem *pile)
{
	int	i;

	i = 0;
	while (i < piles.size)
	{
		if ((pile + i)->nbr != EMPTY)
			break ;
		i++;
	}
	return (piles.size - i);
}
