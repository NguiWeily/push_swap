# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    checker.h                                          :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@student.42.fr>                +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#ifndef CHECKER_H
# define CHECKER_H

# include <o/co.h>

int		execute_action(char *name, t_mem *mem);
void	read_instructions(t_mem *mem);

#endif
