/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: user <wngui@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:16:39 by user              #+#    #+#             */
/*   Updated: 2024/03/17 18:16:42 by user             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

int	main(int c, char **v)
{
	t_mem	mem;
	t_list	*start_tag;

	mem.a = NULL;
	mem.b = NULL;
	mem.print = 1;
	if (c <= 1)
		return (0);
	read_args(c, v, &mem);
	if (!is_ordered(&mem))
	{
		start_tag = (mem.a);
		ft_list_sort(&start_tag);
		tag_list(start_tag, &mem);
		if (mem.max == 5)
			prepare_five(&mem);
		resolve(&mem, 1);
	}
	clear_all(&mem);
	start_tag = NULL;
	return (0);
}
