# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    fi.c                                               :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@student.42.fr>                +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#include <s/so.h>

int	has_tag(t_list *list, int tag)
{
	while (list)
	{
		if (list->index == tag)
			return (1);
		list = list->next;
	}
	return (0);
}

void	prepare_five(t_mem *mem)
{
	t_list	*l;
	int		min;
	int		cur;

	while (has_tag(mem->a, 0) || has_tag(mem->a, mem->max - 1))
	{
		l = mem->a;
		min = 999;
		while (l)
		{
			if (l->index == 0 || l->index == mem->max - 1)
			{
				cur = distance_to_top(mem->a, l->index);
				if (ft_abs(cur) < ft_abs(min))
					min = cur;
			}
			l = l->next;
		}
		if (min == 0)
			push_b(mem);
		if (min < 0)
			rev_rotate_a(mem);
		if (min > 0)
			rotate_a(mem);
	}
}
