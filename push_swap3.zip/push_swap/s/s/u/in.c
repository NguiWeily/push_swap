# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    in.c                                               :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@student.42.fr>                +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#include <s/so.h>

void	tag_list(t_list *start, t_mem *mem)
{
	int	i;

	i = 0;
	while (start)
	{
		start->index = i++;
		start = start->next_sort;
	}
	mem->max = i;
}
