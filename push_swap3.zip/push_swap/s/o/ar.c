# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    ar.c                                               :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@student.42.fr>                +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#include <o/co.h>

void	read_args(int c, char **v, t_mem *mem)
{
	int	j;
	int	i;
	int	prev_space;

	i = 1;
	prev_space = 1;
	while (i < c)
	{
		prev_space = 1;
		j = -1;
		while (v[i][++j])
		{
			if (v[i][j] != '+' && v[i][j] != '-' && v[i][j] != ' '
				&& !ft_isdigit(v[i][j]))
				exit_error(mem);
			if (prev_space == 1 && v[i][j] != ' ')
			{
				push_init(&(mem->a), ft_atoi(argv[i] + j, mem), -1, mem);
				prev_space = 0;
			}
			prev_space = v[i][j] == ' ';
		}
		i++;
	}
}
