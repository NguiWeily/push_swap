# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    ft_utils_3.c                                       :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@42mail.sutd.edu.sg>           +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#include <common/common.h>

int	list_size(t_list *l)
{
	int	i;

	i = 0;
	while (l)
	{
		i++;
		l = l->next;
	}
	return (i);
}

t_list	*get_last(t_list *l)
{
	if (l == NULL)
		return (NULL);
	while (l->next)
	{
		l = l->next;
	}
	return (l);
}

int	list_contains_value(t_list *l, int value)
{
	while (l)
	{
		if (l->value == value)
			return (1);
		l = l->next;
	}
	return (0);
}

int	is_ordered(t_mem *m)
{
	int		prev;
	t_list	*l;

	if (m->b)
		return (0);
	if (!m->a)
		return (1);
	l = m->a;
	prev = l->value;
	while (l)
	{
		if (prev > l->value)
			return (0);
		prev = l->value;
		l = l->next;
	}
	return (1);
}
