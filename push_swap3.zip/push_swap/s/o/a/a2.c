# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    a2.c                                               :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: wngui <wngui@student.42.fr>                +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2024/02/22 13:21:27 by wngui             #+#    #+#              #
#    Updated: 2024/02/22 13:21:30 by wngui            ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#include <o/co.h>

void	rev_rotate_a(t_mem *mem)
{
	put_bottom_to_top(&(mem->a));
	if (mem->print)
		ft_putstr("rra");
}

void	rev_rotate_b(t_mem *mem)
{
	put_bottom_to_top(&(mem->b));
	if (mem->print)
		ft_putstr("rrb");
}

void	rev_rotate_b_a(t_mem *mem)
{
	put_bottom_to_top(&(mem->b));
	put_bottom_to_top(&(mem->a));
	if (mem->print)
		ft_putstr("rrr");
}

void	rotate_a(t_mem *mem)
{
	put_top_to_bottom(&(mem->a));
	if (mem->print)
		ft_putstr("ra");
}

void	rotate_b(t_mem *mem)
{
	put_top_to_bottom(&(mem->b));
	if (mem->print)
		ft_putstr("rb");
}
