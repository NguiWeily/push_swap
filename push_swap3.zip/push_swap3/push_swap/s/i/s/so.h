/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:12:06 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:22:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_H
# define SO_H

# include <o/co.h>

int		hastag(t_list *list, int tag);
void	prepfive(t_mem *mem);

void	taglist(t_list *start, t_mem *mem);

int		setlist(t_list *list, t_list *start, int set);
int		findbigset(t_list *start, int set);

void	rotatetwo(t_mem *mem, int *rot_a, int *rot_b);
void	rotate(t_mem *mem, int rot_a, int rot_b);

void	initresolve(t_mem *mem);
int		lentotop(t_list *a, int tag);
int		lentotag(int tag, int size);
t_list	*nearingrp(t_list *list, int cur_group, int group_sz);
int		okswap(t_list *list);

int		insertlen(t_list *list, int t, int size);
void	calcbrtt(t_mem *m, int max_dist, int *rot_a, int *rot_b);
void	fillb(t_mem *m);
void	resolve(t_mem *m, int cur_group);

#endif
