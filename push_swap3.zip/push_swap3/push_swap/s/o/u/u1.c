/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   u1.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:14:24 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:23:21 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

int	fisdigit(int c)
{
	return (c >= '0' && c <= '9');
}

int	fatoi(char *str, t_mem *mem)
{
	int		ne;
	long	nbr;

	nbr = 0;
	ne = 1;
	while (*str == ' ' || *str == '\t' || *str == '\n'
		|| *str == '\v' || *str == '\f' || *str == '\r')
		++str;
	while (*str == '+' || *str == '-')
	{
		if (*str == '-')
			ne *= -1;
		++str;
	}
	--str;
	while (++str && fisdigit(*str))
	{
		nbr = nbr * 10 + (*str - '0');
		if ((ne == 1 && nbr > 0x7FFFFFFF) || (ne == -1 && nbr > 0x80000000))
			exiterr(mem);
	}
	return ((int)(nbr * ne));
}

int	fabs(int a)
{
	if (a < 0)
		return (-a);
	return (a);
}

int	fmax(int a, int b)
{
	if (a > b)
		return (a);
	return (b);
}

int	fmin(int a, int b)
{
	if (a > b)
		return (b);
	return (a);
}
