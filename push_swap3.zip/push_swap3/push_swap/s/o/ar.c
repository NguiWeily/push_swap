/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ar.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:12:35 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:22:55 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

void	readargs(int c, char **v, t_mem *mem)
{
	int	j;
	int	i;
	int	prev_space;

	i = 1;
	prev_space = 1;
	while (i < c)
	{
		prev_space = 1;
		j = -1;
		while (v[i][++j])
		{
			if (v[i][j] != '+' && v[i][j] != '-' && v[i][j] != ' '
				&& !ft_isdigit(v[i][j]))
				exiterr(mem);
			if (prev_space == 1 && v[i][j] != ' ')
			{
				pushinit(&(mem->a), ft_atoi(v[i] + j, mem), -1, mem);
				prev_space = 0;
			}
			prev_space = v[i][j] == ' ';
		}
		i++;
	}
}
