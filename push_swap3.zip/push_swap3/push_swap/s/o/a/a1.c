/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   a1.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:13:28 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:13:31 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

void	sa(t_mem *mem)
{
	sp(&(mem->a));
	if (mem->print)
		ft_putstr("sa");
}

void	sb(t_mem *mem)
{
	sp(&(mem->b));
	if (mem->print)
		ft_putstr("sb");
}

void	ss(t_mem *mem)
{
	sp(&(mem->b));
	sp(&(mem->a));
	if (mem->print)
		ft_putstr("ss");
}

void	pb(t_mem *mem)
{
	ptx1ox2(&(mem->a), &(mem->b));
	if (mem->print)
		ft_putstr("pb");
}

void	pa(t_mem *mem)
{
	ptx1ox2(&(mem->b), &(mem->a));
	if (mem->print)
		ft_putstr("pa");
}
