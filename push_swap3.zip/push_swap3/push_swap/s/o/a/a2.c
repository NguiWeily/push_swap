/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   a2.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:13:41 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:13:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

void	rra(t_mem *mem)
{
	pbtt(&(mem->a));
	if (mem->print)
		fputstr("rra");
}

void	rrb(t_mem *mem)
{
	pbtt(&(mem->b));
	if (mem->print)
		fputstr("rrb");
}

void	rrr(t_mem *mem)
{
	pbtt(&(mem->b));
	pbtt(&(mem->a));
	if (mem->print)
		fputstr("rrr");
}

void	ra(t_mem *mem)
{
	pttb(&(mem->a));
	if (mem->print)
		fputstr("ra");
}

void	rb(t_mem *mem)
{
	pttb(&(mem->b));
	if (mem->print)
		fputstr("rb");
}
