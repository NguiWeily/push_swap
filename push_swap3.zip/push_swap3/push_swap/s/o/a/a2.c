/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   a2.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:13:41 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:13:44 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

void	rra(t_mem *mem)
{
	pbtt(&(mem->a));
	if (mem->print)
		ft_putstr("rra");
}

void	rrb(t_mem *mem)
{
	pbtt(&(mem->b));
	if (mem->print)
		ft_putstr("rrb");
}

void	rrr(t_mem *mem)
{
	pbtt(&(mem->b));
	pbtt(&(mem->a));
	if (mem->print)
		ft_putstr("rrr");
}

void	ra(t_mem *mem)
{
	pttb(&(mem->a));
	if (mem->print)
		ft_putstr("ra");
}

void	rb(t_mem *mem)
{
	pttb(&(mem->b));
	if (mem->print)
		ft_putstr("rb");
}
