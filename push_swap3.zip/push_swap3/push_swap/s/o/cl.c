/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cl.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:12:49 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:12:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <o/co.h>

void	clearall(t_mem *mem)
{
	freelist(&(mem->a));
	freelist(&(mem->b));
}

void	exiterr(t_mem *mem)
{
	ft_puterr("Error");
	clearall(mem);
	exit(EXIT_FAILURE);
}
