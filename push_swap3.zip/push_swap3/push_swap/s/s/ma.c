/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:16:39 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:16:42 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

int	main(int c, char **v)
{
	t_mem	mem;
	t_list	*start_tag;

	mem.a = NULL;
	mem.b = NULL;
	mem.print = 1;
	if (c <= 1)
		return (0);
	readargs(c, v, &mem);
	if (!isorder(&mem))
	{
		start_tag = (mem.a);
		listsort(&start_tag);
		taglist(start_tag, &mem);
		if (mem.max == 5)
			prepfive(&mem);
		resolve(&mem, 1);
	}
	clearall(&mem);
	start_tag = NULL;
	return (0);
}
