/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ro.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:17:44 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:17:51 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

void	rotatetwo(t_mem *mem, int *rot_a, int *rot_b)
{
	while (*rot_a > 0 && *rot_b > 0)
	{
		(*rot_a)--;
		(*rot_b)--;
		rr(mem);
	}
	while (*rot_a < 0 && *rot_b < 0)
	{
		(*rot_a)++;
		(*rot_b)++;
		rrr(mem);
	}
}

void	rotate(t_mem *mem, int rot_a, int rot_b)
{
	rotatetwo(mem, &rot_a, &rot_b);
	while (rot_a > 0)
	{
		rot_a--;
		ra(mem);
	}
	while (rot_a < 0)
	{
		rot_a++;
		rra(mem);
	}
	while (rot_b > 0)
	{
		rot_b--;
		rb(mem);
	}
	while (rot_b < 0)
	{
		rot_b++;
		rrb(mem);
	}
}
