/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:18:02 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:18:08 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

void	initresolve(t_mem *mem)
{
	mem->big = findbigset(mem->a, 1);
	mem->size = listsize(mem->a);
	mem->group_cnt = ft_max(1, (int)(mem->max / 150.0));
	mem->group_sz = mem->max / mem->group_cnt;
}

int	lentotop(t_list *a, int tag)
{
	int	i;
	int	size;

	i = 0;
	size = listsize(a);
	while (a)
	{
		if (a->index == tag)
			break ;
		a = a->next;
		i++;
	}
	if (i > size / 2)
		i -= size;
	return (i);
}

int	lentotag(int tag, int size)
{
	if (tag >= size / 2)
		tag -= size;
	return (tag);
}

t_list	*nearingrp(t_list *list, int cur_group, int group_sz)
{
	t_list	*closest;
	t_list	*cur;
	int		distance;
	int		cur_dist;

	distance = 0xFFFFFFF;
	closest = NULL;
	cur = list;
	while (cur)
	{
		if (cur->index <= group_sz * cur_group && !cur->keep)
		{
			cur_dist = lentotop(list, cur->index);
			if (ft_abs(cur_dist) < ft_abs(distance))
			{
				distance = cur_dist;
				closest = cur;
				if (distance == 0)
					break ;
			}
		}
		cur = cur->next;
	}
	return (closest);
}
