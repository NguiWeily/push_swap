/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fi.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:17:15 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:17:18 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

int	hastag(t_list *list, int tag)
{
	while (list)
	{
		if (list->index == tag)
			return (1);
		list = list->next;
	}
	return (0);
}

void	prepfive(t_mem *mem)
{
	t_list	*l;
	int		min;
	int		cur;

	while (hastag(mem->a, 0) || hastag(mem->a, mem->max - 1))
	{
		l = mem->a;
		min = 999;
		while (l)
		{
			if (l->index == 0 || l->index == mem->max - 1)
			{
				cur = lentotop(mem->a, l->index);
				if (ft_abs(cur) < ft_abs(min))
					min = cur;
			}
			l = l->next;
		}
		if (min == 0)
			pb(mem);
		if (min < 0)
			rra(mem);
		if (min > 0)
			ra(mem);
	}
}
