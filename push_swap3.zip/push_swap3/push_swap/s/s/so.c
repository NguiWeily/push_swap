/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:16:52 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:17:00 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <s/so.h>

int	insertlen(t_list *list, int t, int size)
{
	t_list	*p;
	t_list	*c;
	int		c_max[2];
	int		i;

	i = 0;
	p = getlast(list);
	c = list;
	c_max[1] = 0xFFFFFFF;
	while (c)
	{
		if ((p->index > c->index && (t < c->index || t > p->index))
			|| (t > p->index && t < c->index))
		{
			c_max[0] = i;
			if (c_max[0] > size / 2)
				c_max[0] -= size;
			if (fabs(c_max[0]) < c_max[1])
				c_max[1] = c_max[0];
		}
		p = c;
		c = c->next;
		i++;
	}
	return (c_max[1]);
}

void	calcbrtt(t_mem *m, int max_dist, int *rot_a, int *rot_b)
{
	int	dist_total;
	int	insert;
	int	distance_b;
	int	i;

	i = 0;
	m->temp = m->b;
	while (m->temp)
	{
		distance_b = lentotag(i++, m->max - m->size);
		insert = insertlen(m->a, m->temp->index, m->size);
		dist_total = fabs(insert) + fabs(distance_b);
		if (insert > 0 && distance_b > 0)
			dist_total -= fmin(distance_b, insert);
		if (insert < 0 && distance_b < 0)
			dist_total += fmax(distance_b, insert);
		if (dist_total < max_dist)
		{
			max_dist = dist_total;
			*rot_a = insert;
			*rot_b = distance_b;
		}
		m->temp = m->temp->next;
	}
}

void	fillb(t_mem *m)
{
	int	rot_a;
	int	rot_b;

	while (m->b)
	{
		calcbrtt(m, 0xFFFFFFF, &rot_a, &rot_b);
		rotate(m, rot_a, rot_b);
		pa(m);
		(m->size)++;
	}
	rotate(m, lentotop(m->a, 0), 0);
}

int	okswap(t_list *list)
{
	t_list	mock;
	t_list	mock2;
	int		count;
	int		count2;

	mock.next = &mock2;
	mock.index = list->next->index;
	mock2.next = list->next->next;
	mock2.index = list->index;
	count = findbigset(list, 0);
	count2 = findbigset(&mock, 0);
	if (count2 > count)
		return (1);
	return (0);
}

void	resolve(t_mem *m, int cur_group)
{
	int	distance;

	initresolve(m);
	while (m->size >= m->big && cur_group <= (m->group_cnt + 1))
	{
		m->temp = nearingrp(m->a, cur_group, m->group_sz);
		if (m->temp == NULL && ++cur_group)
			continue ;
		distance = lentotop(m->a, m->temp->index);
		if (m->a && okswap(m->a))
		{
			sa(m);
			m->big = findbigset(m->a, 1);
		}
		else if (m->a && !m->a->keep && distance == 0)
		{
			pb(m);
			(m->size)--;
		}
		else if (m->group_cnt == 1)
			rr(m);
		else
			rotate(m, fmin(1, fmax(-1, distance)), 0);
	}
	fillb(m);
}
