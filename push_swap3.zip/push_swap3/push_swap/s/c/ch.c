/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ch.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:09:58 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:10:03 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <c/ch.h>

int	runtask(char *name, t_mem *mem)
{
	if (!ft_strcmp(name, "sa"))
		sa(mem);
	else if (!ft_strcmp(name, "sb"))
		sb(mem);
	else if (!ft_strcmp(name, "ss"))
		ss(mem);
	else if (!ft_strcmp(name, "pa"))
		pa(mem);
	else if (!ft_strcmp(name, "pb"))
		pb(mem);
	else if (!ft_strcmp(name, "ra"))
		ra(mem);
	else if (!ft_strcmp(name, "rb"))
		rb(mem);
	else if (!ft_strcmp(name, "rr"))
		rr(mem);
	else if (!ft_strcmp(name, "rra"))
		rra(mem);
	else if (!ft_strcmp(name, "rrb"))
		rrb(mem);
	else if (!ft_strcmp(name, "rrr"))
		rrr(mem);
	else
		return (0);
	return (1);
}

void	readtask(t_mem *mem)
{
	char	task[4];
	int		index;
	int		prev_index;

	index = 0;
	while (index < 4)
	{
		prev_index = index;
		index += read(0, task + index, 1);
		if (prev_index == index)
			break ;
		if (task[prev_index] == '\n')
		{
			task[prev_index] = 0;
			if (!runtask(task, mem))
				exiterr(mem);
			index = 0;
		}
	}
	if (index == 4)
		exiterr(mem);
}
