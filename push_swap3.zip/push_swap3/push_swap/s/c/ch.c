/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ch.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:09:58 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:10:03 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <c/ch.h>

int	runtask(char *name, t_mem *mem)
{
	if (!fstrcmp(name, "sa"))
		sa(mem);
	else if (!fstrcmp(name, "sb"))
		sb(mem);
	else if (!fstrcmp(name, "ss"))
		ss(mem);
	else if (!fstrcmp(name, "pa"))
		pa(mem);
	else if (!fstrcmp(name, "pb"))
		pb(mem);
	else if (!fstrcmp(name, "ra"))
		ra(mem);
	else if (!fstrcmp(name, "rb"))
		rb(mem);
	else if (!fstrcmp(name, "rr"))
		rr(mem);
	else if (!fstrcmp(name, "rra"))
		rra(mem);
	else if (!fstrcmp(name, "rrb"))
		rrb(mem);
	else if (!fstrcmp(name, "rrr"))
		rrr(mem);
	else
		return (0);
	return (1);
}

void	readtask(t_mem *mem)
{
	char	task[4];
	int		index;
	int		prev_index;

	index = 0;
	while (index < 4)
	{
		prev_index = index;
		index += read(0, task + index, 1);
		if (prev_index == index)
			break ;
		if (task[prev_index] == '\n')
		{
			task[prev_index] = 0;
			if (!runtask(task, mem))
				exiterr(mem);
			index = 0;
		}
	}
	if (index == 4)
		exiterr(mem);
}
