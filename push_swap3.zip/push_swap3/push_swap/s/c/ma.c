/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ma.c                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wngui <wngui@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/03/17 18:10:47 by wngui             #+#    #+#             */
/*   Updated: 2024/03/17 18:10:52 by wngui            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <c/ch.h>

int	main(int c, char **v)
{
	t_mem	mem;

	mem.a = NULL;
	mem.b = NULL;
	mem.print = 0;
	if (c <= 1)
		return (0);
	readargs(c, v, &mem);
	readtask(&mem);
	if (isorder(&mem))
		fputstr("OK");
	else
		fputstr("KO");
	clearall(&mem);
	return (0);
}
